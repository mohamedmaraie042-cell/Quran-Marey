package com.mohamedmarey.quran;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.Locale;

public class AdhanService extends Service implements TextToSpeech.OnInitListener {
    public static final String ACTION_PLAY = "com.mohamedmarey.quran.PLAY_ADHAN";
    public static final String ACTION_STOP = "com.mohamedmarey.quran.STOP_ADHAN";
    private static final String CHANNEL_ID = "quran_marey_adhan";
    private static final int NOTIFICATION_ID = 7411;
    // CC0 / Public Domain dedication: Wikimedia Commons, "Beautiful adhan.ogg" by Adam-synagda.
    private static final String ADHAN_URL = "https://upload.wikimedia.org/wikipedia/commons/b/b0/Beautiful_adhan.ogg";

    private TextToSpeech tts;
    private MediaPlayer player;
    private String prayerName = "الصلاة";
    private boolean fallbackStarted = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAdhan();
            return START_NOT_STICKY;
        }

        prayerName = intent != null ? intent.getStringExtra("prayer_name") : "الصلاة";
        if (prayerName == null || prayerName.trim().isEmpty()) prayerName = "الصلاة";
        startForeground(NOTIFICATION_ID, buildNotification(prayerName));
        playRecordedAdhan();
        return START_NOT_STICKY;
    }

    private void playRecordedAdhan() {
        fallbackStarted = false;
        releasePlayer();
        shutdownTts();
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(ADHAN_URL);
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(mp -> stopSelf());
            player.setOnErrorListener((mp, what, extra) -> {
                startTtsFallback();
                return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            startTtsFallback();
        }
    }

    private void startTtsFallback() {
        if (fallbackStarted) return;
        fallbackStarted = true;
        releasePlayer();
        tts = new TextToSpeech(this, this);
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || tts == null) {
            stopSelf();
            return;
        }

        int language = tts.setLanguage(new Locale("ar", "SA"));
        if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
            stopSelf();
            return;
        }

        tts.setSpeechRate(0.72f);
        tts.setPitch(0.88f);
        tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build());
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {}
            @Override public void onDone(String utteranceId) { stopSelf(); }
            @Override public void onError(String utteranceId) { stopSelf(); }
        });
        tts.speak(buildAdhanText(prayerName), TextToSpeech.QUEUE_FLUSH, null,
                "quran-marey-adhan-" + System.currentTimeMillis());
    }

    private String buildAdhanText(String prayer) {
        StringBuilder s = new StringBuilder();
        s.append("الله أكبر. الله أكبر. الله أكبر. الله أكبر. ");
        s.append("أشهد أن لا إله إلا الله. أشهد أن لا إله إلا الله. ");
        s.append("أشهد أن محمدًا رسول الله. أشهد أن محمدًا رسول الله. ");
        s.append("حي على الصلاة. حي على الصلاة. ");
        s.append("حي على الفلاح. حي على الفلاح. ");
        if (prayer != null && prayer.contains("الفجر")) {
            s.append("الصلاة خير من النوم. الصلاة خير من النوم. ");
        }
        s.append("الله أكبر. الله أكبر. لا إله إلا الله.");
        return s.toString();
    }

    private Notification buildNotification(String prayer) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 100, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, AdhanService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 101, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setSmallIcon(R.drawable.app_icon)
                .setContentTitle("حان الآن موعد " + prayer)
                .setContentText("Quran Marey · جاري تشغيل الأذان")
                .setContentIntent(openPi)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_media_pause, "إيقاف الأذان", stopPi).build());
        return builder.build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "الأذان ومواقيت الصلاة",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("تنبيهات الصلاة وتشغيل الأذان");
            channel.setSound(null, null);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void stopAdhan() {
        releasePlayer();
        shutdownTts();
        stopForeground(true);
        stopSelf();
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    private void shutdownTts() {
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
            try { tts.shutdown(); } catch (Exception ignored) {}
            tts = null;
        }
    }

    @Override
    public void onDestroy() {
        releasePlayer();
        shutdownTts();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
