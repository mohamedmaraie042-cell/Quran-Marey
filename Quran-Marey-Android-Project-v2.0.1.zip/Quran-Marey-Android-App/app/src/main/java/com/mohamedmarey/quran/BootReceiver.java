package com.mohamedmarey.quran;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try { PrayerAlarmScheduler.restore(context); }
        catch (Exception e) { CrashLogger.recordRuntime(context, "BootReceiver", "فشل استعادة منبهات الصلاة", e.toString()); }
        try { PrayerTimesNotificationManager.restore(context); }
        catch (Exception e) { CrashLogger.recordRuntime(context, "BootReceiver", "فشل استعادة إشعار المواقيت", e.toString()); }
        try { SmartReminderScheduler.restore(context); }
        catch (Exception e) { CrashLogger.recordRuntime(context, "BootReceiver", "فشل استعادة التذكيرات", e.toString()); }
    }
}
