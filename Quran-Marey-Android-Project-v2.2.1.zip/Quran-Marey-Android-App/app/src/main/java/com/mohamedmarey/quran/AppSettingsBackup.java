package com.mohamedmarey.quran;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.Map;

/** Whitelisted native preference backup; excludes schedules, tokens, crash logs and media files. */
public final class AppSettingsBackup {
    private AppSettingsBackup() {}

    public static String exportJson(Context context) {
        try {
            JSONObject root = new JSONObject();
            root.put("version", 1);
            root.put("adhan", exportPrefs(context, "quran_marey_adhan_prefs", null));

            JSONObject prayer = new JSONObject();
            SharedPreferences pp = context.getSharedPreferences("quran_marey_prayers", Context.MODE_PRIVATE);
            prayer.put("adhan_enabled", pp.getBoolean("adhan_enabled", false));
            String calc = PrayerCalculationConfig.exportRaw(context);
            if (!calc.isEmpty()) prayer.put("calculation_config", new JSONObject(calc));
            root.put("prayer", prayer);

            JSONObject notification = new JSONObject();
            notification.put("enabled", PrayerTimesNotificationManager.isEnabled(context));
            root.put("prayer_notification", notification);
            root.put("smart_reminders", exportPrefs(context, "al_muslim_smart_reminders", null));
            root.put("downloads", exportPrefs(context, "al_muslim_downloads", new String[]{"wifi_only"}));
            return root.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public static boolean importJson(Context context, String raw) {
        try {
            JSONObject root = new JSONObject(raw == null ? "{}" : raw);
            importPrefs(context, "quran_marey_adhan_prefs", root.optJSONObject("adhan"), null);
            JSONObject prayer = root.optJSONObject("prayer");
            if (prayer != null) {
                context.getSharedPreferences("quran_marey_prayers", Context.MODE_PRIVATE)
                        .edit().putBoolean("adhan_enabled", prayer.optBoolean("adhan_enabled", false)).apply();
                JSONObject calc = prayer.optJSONObject("calculation_config");
                if (calc != null) PrayerCalculationConfig.save(context, calc.toString());
            }
            JSONObject notification = root.optJSONObject("prayer_notification");
            if (notification != null) PrayerTimesNotificationManager.setEnabled(context, notification.optBoolean("enabled", true));
            importPrefs(context, "al_muslim_smart_reminders", root.optJSONObject("smart_reminders"), null);
            importPrefs(context, "al_muslim_downloads", root.optJSONObject("downloads"), new String[]{"wifi_only"});

            PrayerAlarmScheduler.restore(context);
            PrayerTimesNotificationManager.restore(context);
            SmartReminderScheduler.restore(context);
            AdhanAudioCache.ensureAllCachedAsync(context);
            return true;
        } catch (Exception e) {
            CrashLogger.recordRuntime(context, "BackupImport", "فشل استعادة الإعدادات الأصلية", e.toString());
            return false;
        }
    }

    private static JSONObject exportPrefs(Context context, String name, String[] allowKeys) throws Exception {
        JSONObject out = new JSONObject();
        Map<String, ?> all = context.getSharedPreferences(name, Context.MODE_PRIVATE).getAll();
        for (Map.Entry<String, ?> e : all.entrySet()) {
            if (!allowed(e.getKey(), allowKeys)) continue;
            Object v = e.getValue();
            if (v instanceof String || v instanceof Boolean || v instanceof Integer || v instanceof Long || v instanceof Float) {
                out.put(e.getKey(), v);
            }
        }
        return out;
    }

    private static void importPrefs(Context context, String name, JSONObject object, String[] allowKeys) {
        if (object == null) return;
        SharedPreferences.Editor editor = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit();
        for (String key : object.keySet()) {
            if (!allowed(key, allowKeys)) continue;
            Object v = object.opt(key);
            if (v instanceof Boolean) editor.putBoolean(key, (Boolean) v);
            else if (v instanceof Integer) editor.putInt(key, (Integer) v);
            else if (v instanceof Long) editor.putLong(key, (Long) v);
            else if (v instanceof Double) editor.putFloat(key, ((Double) v).floatValue());
            else if (v != null && v != JSONObject.NULL) editor.putString(key, String.valueOf(v));
        }
        editor.apply();
    }

    private static boolean allowed(String key, String[] allowKeys) {
        if (allowKeys == null) return true;
        for (String k : allowKeys) if (k.equals(key)) return true;
        return false;
    }
}
