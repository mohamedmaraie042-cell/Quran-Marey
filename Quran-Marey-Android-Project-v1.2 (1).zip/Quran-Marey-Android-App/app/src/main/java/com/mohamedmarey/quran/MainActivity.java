package com.mohamedmarey.quran;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.widget.Toast;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech textToSpeech;
    private volatile boolean ttsReady = false;

    @SuppressLint({"SetJavaScriptEnabled", "ObsoleteSdkInt"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(11, 59, 46));
        getWindow().setNavigationBarColor(Color.rgb(11, 59, 46));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 240, 230));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        initTextToSpeech();
        webView.addJavascriptInterface(new AndroidBridge(), "QuranAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternalIfNeeded(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalIfNeeded(Uri.parse(url));
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                return super.onConsoleMessage(cm);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean openExternalIfNeeded(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme();
        if (scheme == null || "file".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme)) {
            return false;
        }

        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
            }
            return true;
        }
        return false;
    }

    private void initTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                ttsReady = false;
                notifyTtsState("error", "تعذر تشغيل محرك النطق في الهاتف.");
                return;
            }

            int result = textToSpeech.setLanguage(new Locale("ar", "SA"));
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
            textToSpeech.setSpeechRate(0.88f);

            if (ttsReady) {
                notifyTtsState("ready", "محرك النطق العربي جاهز.");
            } else {
                notifyTtsState("error", "اللغة العربية غير متاحة في محرك النطق على الهاتف.");
            }
        });

        textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                notifyTtsState("start", "جاري قراءة التفسير صوتيًا...");
            }

            @Override
            public void onDone(String utteranceId) {
                notifyTtsState("done", "انتهت قراءة التفسير.");
            }

            @Override
            public void onError(String utteranceId) {
                notifyTtsState("error", "تعذر تشغيل قراءة التفسير صوتيًا.");
            }
        });
    }

    private void notifyTtsState(String state, String message) {
        if (webView == null) return;
        final String js = "window.onNativeTtsState && window.onNativeTtsState("
                + jsQuote(state) + "," + jsQuote(message) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private static String jsQuote(String value) {
        if (value == null) return "null";
        return "\"" + value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r") + "\"";
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void copyToClipboard(String text) {
            if (text == null) return;
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    clipboard.setPrimaryClip(ClipData.newPlainText("Quran Marey", text));
                }
            });
        }

        @JavascriptInterface
        public boolean isTtsReady() {
            return ttsReady;
        }

        @JavascriptInterface
        public void speakArabic(String text) {
            if (text == null || text.trim().isEmpty()) return;
            runOnUiThread(() -> {
                if (!ttsReady || textToSpeech == null) {
                    notifyTtsState("error", "محرك النطق العربي غير جاهز على الهاتف.");
                    return;
                }
                String utteranceId = "tafsir-" + System.currentTimeMillis();
                int result = textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
                if (result == TextToSpeech.ERROR) {
                    notifyTtsState("error", "تعذر بدء قراءة التفسير صوتيًا.");
                }
            });
        }

        @JavascriptInterface
        public void stopTts() {
            runOnUiThread(() -> {
                if (textToSpeech != null) textToSpeech.stop();
                notifyTtsState("stopped", "تم إيقاف صوت التفسير.");
            });
        }

        @JavascriptInterface
        public void downloadAudio(String url, String fileName) {
            runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(url == null ? "" : url.trim());
                    if (!"https".equalsIgnoreCase(uri.getScheme())) {
                        notifyDownloadState("error", "رابط التنزيل غير آمن أو غير صالح.", "");
                        return;
                    }

                    String safeName = sanitizeFileName(fileName);
                    if (safeName.isEmpty()) safeName = "quran-audio.mp3";
                    if (!safeName.toLowerCase(Locale.US).endsWith(".mp3")) safeName += ".mp3";

                    DownloadManager.Request request = new DownloadManager.Request(uri);
                    request.setTitle(safeName.replace(".mp3", ""));
                    request.setDescription("Quran Marey - تلاوة القرآن الكريم");
                    request.setMimeType("audio/mpeg");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setAllowedOverMetered(true);
                    request.setAllowedOverRoaming(false);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "QuranMarey/" + safeName);
                    } else {
                        request.setDestinationInExternalFilesDir(MainActivity.this, Environment.DIRECTORY_MUSIC, "QuranMarey/" + safeName);
                    }

                    DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (manager == null) {
                        notifyDownloadState("error", "خدمة التنزيل غير متاحة على الهاتف.", safeName);
                        return;
                    }

                    long id = manager.enqueue(request);
                    Toast.makeText(MainActivity.this, "بدأ تنزيل التلاوة", Toast.LENGTH_SHORT).show();
                    notifyDownloadState("started", "بدأ تنزيل التلاوة. سيظهر إشعار عند اكتمالها ويمكن العثور عليها داخل مجلد QuranMarey.", safeName + "#" + id);
                } catch (Exception e) {
                    notifyDownloadState("error", "تعذر بدء تنزيل التلاوة.", "");
                }
            });
        }
    }

    private static String sanitizeFileName(String value) {
        if (value == null) return "";
        return value.replaceAll("[\\/:*?\"<>|\n\r\t]", "-").trim();
    }

    private void notifyDownloadState(String state, String message, String data) {
        if (webView == null) return;
        final String js = "window.onNativeDownloadState && window.onNativeDownloadState("
                + jsQuote(state) + "," + jsQuote(message) + "," + jsQuote(data) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }

        webView.evaluateJavascript(
                "window.handleAndroidBack ? window.handleAndroidBack() : false",
                value -> {
                    if (!"true".equalsIgnoreCase(String.valueOf(value))) {
                        if (webView != null && webView.canGoBack()) {
                            webView.goBack();
                        } else {
                            MainActivity.super.onBackPressed();
                        }
                    }
                }
        );
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("QuranAndroid");
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
