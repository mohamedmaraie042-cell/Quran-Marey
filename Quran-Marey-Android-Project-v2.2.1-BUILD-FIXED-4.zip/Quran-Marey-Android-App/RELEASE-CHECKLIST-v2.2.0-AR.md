# المسلم v2.2.0 — بوابة الإصدار Production

هذه قائمة **اختبار فعلية يجب تنفيذها قبل النشر**؛ وجودها لا يعني أن الأجهزة المذكورة تم اختبارها تلقائيًا.

## بوابة CI
- `node scripts/regression-check.mjs`
- `testDebugUnitTest`
- `lintDebug`
- `assembleDebug`
- عند وجود أسرار التوقيع فقط: `bundleRelease` وإنتاج AAB موقّع.

## مصفوفة Android
اختبر على Android 7 (API 24)، Android 10، Android 13، Android 15، Android 16، مع جهاز/محاكي بحجم خط 100% و150% وTalkBack.

## الشركات والبطارية
اختبر Samsung وXiaomi وOppo/Realme على الأقل: قفل الشاشة، حذف التطبيق من Recent Apps، Battery Saver، إعادة التشغيل، واستمرار القرآن/إشعار المواقيت/جدولة الأذان.

## الصلاة والأذان
- السماح ورفض Notifications.
- السماح ورفض Exact Alarms.
- السماح ورفض Full-screen intent؛ عند الرفض يجب أن يبقى إشعار عالي الأولوية قابلًا للفتح بدون Crash.
- تغيير Timezone وDST ثم إعادة جدولة المواقيت.
- Restart ثم التأكد من استعادة المنبهات والإشعار الدائم.

## القرآن والصوت
- صفحات 1 و2 و604، السحب والقفز برقم الصفحة، وFallback عند انقطاع الإنترنت.
- تشغيل القرآن ثم قفل الشاشة 30 دقيقة؛ Pause/Resume/Next/Previous من Lock screen وBluetooth.
- قطع Wi‑Fi/بيانات ثم عودتها وملاحظة الاستعادة بدون تشغيل صوتين معًا.

## الخصوصية والنسخ
- رفض الموقع ثم اختيار المنطقة يدويًا.
- قبول الموقع التقريبي فقط والتأكد من عدم طلب Fine Location.
- تصدير/استيراد النسخة المحلية ثم فحص الملاحظات والمفضلة.
- تأكيد أن System Cloud Backup/Device Transfer لا ينسخ SharedPreferences/WebView app data الحساسة وفق القواعد الحالية.

## المتجر
- نشر `docs/privacy-policy.html` على HTTPS عام وإضافة الرابط في Play Console.
- إكمال Data Safety طبقًا لـ`PLAY-DATA-SAFETY-AR.md` بعد مراجعة إعدادات Firebase الفعلية.
- مراجعة تصريح `SCHEDULE_EXACT_ALARM` و`USE_FULL_SCREEN_INTENT` في Play Console وتوثيق أن وظيفة الأذان/المنبه هي سبب الاستخدام.
- قبل رفع سياسة الخصوصية، استبدل `{{DEVELOPER_NAME}}` و`{{PRIVACY_CONTACT}}` بالقيم الحقيقية المطابقة لبيانات المتجر.
