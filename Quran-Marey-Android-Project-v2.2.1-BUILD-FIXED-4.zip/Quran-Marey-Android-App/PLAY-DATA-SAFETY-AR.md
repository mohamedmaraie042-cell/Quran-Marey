# Google Play — Privacy / Data Safety checklist

الإصدار: 2.2.0

- Privacy Policy: استخدم `docs/privacy-policy.html` على رابط عام ثم ضعه في Play Console.
- Location: التطبيق يطلب `ACCESS_COARSE_LOCATION` فقط، وبطلب من المستخدم عند ميزة تحديد الموقع التلقائي.
- Purpose: مواقيت الصلاة والقبلة/الموقع داخل التطبيق.
- External processing: عند استخدام المواقيت المتصلة قد ترسل الإحداثيات إلى AlAdhan.
- FCM: بعد إضافة Firebase الحقيقي، Firebase/Google يعالج FCM token لتوصيل الإشعارات.
- Notes/bookmarks/settings/saved locations: تخزين محلي؛ مستبعدة من Android Cloud Backup عبر dataExtractionRules/backup_rules.
- Manual backup export: يتم فقط بطلب المستخدم عبر مشاركة JSON.
- لا يوجد حساب مطلوب ولا GitHub write token داخل تطبيق المستخدم.

يجب مراجعة نموذج Data Safety النهائي في Play Console مقابل نسخة الإنتاج الفعلية وأي SDKs إضافية قبل الإرسال.

- قبل النشر العام لسياسة الخصوصية استبدل `{{DEVELOPER_NAME}}` و`{{PRIVACY_CONTACT}}` ببيانات المطوّر الفعلية.
