package com.mohamedmarey.quran;

import static org.junit.Assert.*;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;

@RunWith(AndroidJUnit4.class)
public class ProductionSmokeInstrumentedTest {
    @Test public void productionManifestTargetsApi36AndUsesCoarseLocationOnly() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        assertTrue(context.getApplicationInfo().targetSdkVersion >= 36);
        PackageInfo pi = context.getPackageManager().getPackageInfo(
                context.getPackageName(), PackageManager.GET_PERMISSIONS);
        assertNotNull(pi.requestedPermissions);
        assertTrue(Arrays.asList(pi.requestedPermissions).contains("android.permission.ACCESS_COARSE_LOCATION"));
        assertFalse(Arrays.asList(pi.requestedPermissions).contains("android.permission.ACCESS_FINE_LOCATION"));
    }

    @Test public void productionCriticalComponentsArePackaged() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PackageManager pm = context.getPackageManager();
        assertNotNull(pm.getReceiverInfo(new android.content.ComponentName(context, BootReceiver.class), 0));
        assertNotNull(pm.getServiceInfo(new android.content.ComponentName(context, QuranAudioService.class), 0));
        assertNotNull(pm.getServiceInfo(new android.content.ComponentName(context, AdhanService.class), 0));
        assertNotNull(pm.getServiceInfo(new android.content.ComponentName(context, FcmMessageService.class), 0));
    }
}
