package com.mohamedmarey.quran;

import org.json.JSONObject;
import org.junit.Test;

import static org.junit.Assert.*;

public class LocalPrayerCalculatorTest {
    @Test public void missingCoordinatesAreRejectedInsteadOfBecomingZeroZero() {
        PrayerCalculationConfig c = new PrayerCalculationConfig(
                null, null, 5, 0, 0, "Africa/Cairo", "Cairo", "Egypt", new JSONObject());
        assertFalse(c.isUsable());
    }

    @Test public void selectedCalculationMethodChangesPrayerTimes() throws Exception {
        PrayerCalculationConfig ummAlQura = new PrayerCalculationConfig(
                30.0444, 31.2357, 4, 0, 0, "Africa/Cairo", "Cairo", "Egypt", new JSONObject());
        PrayerCalculationConfig egyptian = new PrayerCalculationConfig(
                30.0444, 31.2357, 5, 0, 0, "Africa/Cairo", "Cairo", "Egypt", new JSONObject());
        JSONObject a = LocalPrayerCalculator.calculateDayJson(2026, 8, 16, ummAlQura);
        JSONObject b = LocalPrayerCalculator.calculateDayJson(2026, 8, 16, egyptian);
        assertNotNull(a); assertNotNull(b);
        assertNotEquals(a.getJSONObject("timings").getString("Fajr"), b.getJSONObject("timings").getString("Fajr"));
        assertNotEquals(a.getJSONObject("timings").getString("Isha"), b.getJSONObject("timings").getString("Isha"));
    }

    @Test public void cairoTimezoneIsUsedIndependentlyOfDeviceTimezone() throws Exception {
        PrayerCalculationConfig c = new PrayerCalculationConfig(
                30.0444, 31.2357, 5, 0, 0, "Africa/Cairo", "Cairo", "Egypt", new JSONObject());
        JSONObject day = LocalPrayerCalculator.calculateDayJson(2026, 3, 24, c);
        assertEquals("Africa/Cairo", day.getString("timezone"));
    }
}
