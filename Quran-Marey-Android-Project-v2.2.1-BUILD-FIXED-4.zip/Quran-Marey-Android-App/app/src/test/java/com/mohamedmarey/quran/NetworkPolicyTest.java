package com.mohamedmarey.quran;

import org.junit.Test;
import static org.junit.Assert.*;

public class NetworkPolicyTest {
    @Test public void allowsKnownQuranHostsOnly() {
        assertTrue(NetworkPolicy.isAllowedQuranAudioUrl("https://server8.mp3quran.net/afs/001.mp3"));
        assertTrue(NetworkPolicy.isAllowedQuranAudioUrl("https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/1.mp3"));
        assertTrue(NetworkPolicy.isAllowedQuranAudioUrl("https://github.com/The-Quran-Project/Quran-Audio-Chapters/raw/refs/heads/main/Data/x/1.mp3"));
        assertFalse(NetworkPolicy.isAllowedQuranAudioUrl("http://server8.mp3quran.net/afs/001.mp3"));
        assertFalse(NetworkPolicy.isAllowedQuranAudioUrl("https://evil.example/audio.mp3"));
    }

    @Test public void prayerApiIsPinnedToAlAdhan() {
        assertTrue(NetworkPolicy.isAllowedPrayerApiUrl("https://api.aladhan.com/v1/timings/01-01-2026"));
        assertFalse(NetworkPolicy.isAllowedPrayerApiUrl("https://example.com/v1/timings"));
    }
    @Test public void adhanCacheOnlyAllowsTvQuranDownloadHost() {
        assertTrue(NetworkPolicy.isAllowedAdhanUrl("https://download.tvquran.com/download/TvQuran.com__Athan/TvQuran.com__04.athan.mp3"));
        assertFalse(NetworkPolicy.isAllowedAdhanUrl("http://download.tvquran.com/a.mp3"));
        assertFalse(NetworkPolicy.isAllowedAdhanUrl("https://evil.example/a.mp3"));
    }

}
