package com.mohamedmarey.quran;

import org.junit.Test;
import static org.junit.Assert.*;

public class QuranPageLogicTest {
    @Test public void mushafPagesAreAlwaysClampedTo604() {
        assertEquals(1, QuranPageLogic.clampPage(-20));
        assertEquals(1, QuranPageLogic.clampPage(1));
        assertEquals(604, QuranPageLogic.clampPage(604));
        assertEquals(604, QuranPageLogic.clampPage(900));
        assertTrue(QuranPageLogic.isValidPage(300));
        assertFalse(QuranPageLogic.isValidPage(605));
    }
}
