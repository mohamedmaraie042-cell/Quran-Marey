package com.mohamedmarey.quran;

import org.junit.Test;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import static org.junit.Assert.*;

public class PrayerScheduleLogicTest {
    @Test public void preAlertIsClamped() {
        assertEquals(0, PrayerScheduleLogic.clampPreMinutes(-5));
        assertEquals(30, PrayerScheduleLogic.clampPreMinutes(30));
        assertEquals(120, PrayerScheduleLogic.clampPreMinutes(999));
    }

    @Test public void futureThresholdPreventsImmediateDuplicateAlarm() {
        long now = 1_000_000L;
        assertFalse(PrayerScheduleLogic.isFutureEnough(now, now + 10_000L));
        assertTrue(PrayerScheduleLogic.isFutureEnough(now, now + 16_000L));
    }

    @Test public void cairoDstDatesRemainChronologicallyOrdered() {
        ZoneId cairo = ZoneId.of("Africa/Cairo");
        long before = ZonedDateTime.of(2026, 4, 23, 23, 30, 0, 0, cairo).toInstant().toEpochMilli();
        long after = ZonedDateTime.of(2026, 4, 24, 1, 30, 0, 0, cairo).toInstant().toEpochMilli();
        assertTrue(after > before);
        assertNotEquals(PrayerScheduleLogic.requestCode("الفجر", before), PrayerScheduleLogic.requestCode("الفجر", after));
    }
}
