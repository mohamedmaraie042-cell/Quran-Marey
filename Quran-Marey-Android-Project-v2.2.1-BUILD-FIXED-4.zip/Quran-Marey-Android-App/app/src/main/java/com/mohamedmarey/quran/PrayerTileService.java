package com.mohamedmarey.quran;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

import org.json.JSONObject;

public class PrayerTileService extends TileService {
    private static final String PREFS = "quran_marey_prayer_times_notification";

    @Override
    public void onStartListening() {
        super.onStartListening();
        Tile tile = getQsTile();
        if (tile == null) return;
        String label = "الصلاة القادمة";
        try {
            SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONObject j = new JSONObject(p.getString("today_json", "{}"));
            String name = j.optString("nextName", "").trim();
            String time = j.optString("nextTime", "").trim();
            if (!name.isEmpty()) label = name + (time.isEmpty() ? "" : " " + time);
        } catch (Exception ignored) {}
        tile.setLabel(label);
        tile.setState(Tile.STATE_ACTIVE);
        tile.updateTile();
    }

    @SuppressLint("StartActivityAndCollapseDeprecated")
    @Override
    public void onClick() {
        super.onClick();
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("open_tab", "prayer");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (Build.VERSION.SDK_INT >= 34) {
            PendingIntent pi = PendingIntent.getActivity(this, 7301, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            startActivityAndCollapse(pi);
        } else {
            @SuppressWarnings("deprecation")
            Intent legacy = intent;
            startActivityAndCollapse(legacy);
        }
    }
}
