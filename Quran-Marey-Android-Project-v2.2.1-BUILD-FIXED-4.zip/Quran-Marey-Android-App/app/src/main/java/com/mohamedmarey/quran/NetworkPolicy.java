package com.mohamedmarey.quran;

import java.net.URI;
import java.util.Locale;

/** Central allow-list for URLs reachable from privileged native bridges/services. */
public final class NetworkPolicy {
    private NetworkPolicy() {}

    public static boolean isAllowedQuranAudioUrl(String raw) {
        if (raw == null || raw.trim().isEmpty()) return false;
        try {
            URI uri = URI.create(raw.trim());
            if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.US);
            return host.equals("mp3quran.net")
                    || host.endsWith(".mp3quran.net")
                    || host.equals("cdn.islamic.network")
                    || host.equals("github.com")
                    || host.equals("raw.githubusercontent.com");
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isAllowedAdhanUrl(String raw) {
        if (raw == null || raw.trim().isEmpty()) return false;
        try {
            URI uri = URI.create(raw.trim());
            return "https".equalsIgnoreCase(uri.getScheme())
                    && "download.tvquran.com".equalsIgnoreCase(uri.getHost());
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isAllowedPrayerApiUrl(String raw) {
        if (raw == null || raw.trim().isEmpty()) return false;
        try {
            URI uri = URI.create(raw.trim());
            return "https".equalsIgnoreCase(uri.getScheme())
                    && "api.aladhan.com".equalsIgnoreCase(uri.getHost());
        } catch (Exception ignored) {
            return false;
        }
    }
}
