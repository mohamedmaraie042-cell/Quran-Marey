package com.mohamedmarey.quran;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class SmartReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "smart_worship_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        String type = intent == null ? "" : intent.getStringExtra("type");
        String title = "المسلم";
        String text = "وردك اليومي في انتظارك";
        String tab = "more";
        if ("morning".equals(type)) { title = "أذكار الصباح"; text = "ابدأ يومك بذكر الله"; tab = "adhkar"; }
        else if ("evening".equals(type)) { title = "أذكار المساء"; text = "حان وقت أذكار المساء"; tab = "adhkar_evening"; }
        else if ("friday".equals(type)) { title = "يوم الجمعة"; text = "سورة الكهف والصلاة على النبي ﷺ"; tab = "friday"; }
        else if ("night".equals(type)) { title = "قيام الليل"; text = "تذكير اختياري بقيام الليل"; tab = "prayer"; }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel c = new NotificationChannel(CHANNEL, "تذكيرات العبادة", NotificationManager.IMPORTANCE_DEFAULT);
                c.setDescription("أذكار وورد الجمعة وقيام الليل حسب اختيار المستخدم");
                nm.createNotificationChannel(c);
            }
        }

        Intent open = new Intent(context, MainActivity.class);
        open.putExtra("open_tab", tab);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 8000 + Math.abs(type == null ? 0 : type.hashCode() % 1000), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL) : new Notification.Builder(context);
        b.setSmallIcon(R.drawable.app_icon).setContentTitle(title).setContentText(text)
                .setContentIntent(pi).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER)
                .setPriority(Notification.PRIORITY_DEFAULT);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(8100 + Math.abs(type == null ? 0 : type.hashCode() % 500), b.build());
    }
}
