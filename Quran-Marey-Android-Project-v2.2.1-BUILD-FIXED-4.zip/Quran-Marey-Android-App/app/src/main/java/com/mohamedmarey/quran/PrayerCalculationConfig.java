package com.mohamedmarey.quran;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.TimeZone;

/** Persisted prayer-calculation settings used by the native rolling scheduler. */
public final class PrayerCalculationConfig {
    private static final String PREFS = "quran_marey_prayer_calc";
    private static final String KEY_JSON = "config_json";

    public final Double lat;
    public final Double lon;
    public final int method;
    public final int school;
    public final int preMinutes;
    public final String timezone;
    public final String city;
    public final String country;
    public final JSONObject adjustments;

    PrayerCalculationConfig(Double lat, Double lon, int method, int school,
                                    int preMinutes, String timezone, String city,
                                    String country, JSONObject adjustments) {
        this.lat = lat;
        this.lon = lon;
        this.method = method;
        this.school = school;
        this.preMinutes = PrayerScheduleLogic.clampPreMinutes(preMinutes);
        this.timezone = normalizeTimezone(timezone, country);
        this.city = city == null ? "" : city;
        this.country = country == null ? "" : country;
        this.adjustments = adjustments == null ? new JSONObject() : adjustments;
    }

    public static boolean save(Context context, String json) {
        if (context == null || json == null) return false;
        try {
            JSONObject o = new JSONObject(json);
            PrayerCalculationConfig parsed = parse(o);
            if (!parsed.isUsable()) return false;
            prefs(context).edit().putString(KEY_JSON, o.toString()).apply();
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static PrayerCalculationConfig load(Context context) {
        try {
            String raw = prefs(context).getString(KEY_JSON, null);
            if (raw == null || raw.trim().isEmpty()) return null;
            PrayerCalculationConfig c = parse(new JSONObject(raw));
            return c.isUsable() ? c : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String exportRaw(Context context) {
        return prefs(context).getString(KEY_JSON, "");
    }

    public static void importRaw(Context context, String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            prefs(context).edit().remove(KEY_JSON).apply();
            return;
        }
        save(context, raw);
    }

    public boolean isUsable() {
        return lat != null && lon != null
                && Double.isFinite(lat) && Double.isFinite(lon)
                && lat >= -90d && lat <= 90d && lon >= -180d && lon <= 180d
                && timezone != null && !timezone.trim().isEmpty();
    }

    private static PrayerCalculationConfig parse(JSONObject o) {
        Double lat = nullableDouble(o, "lat");
        Double lon = nullableDouble(o, "lon");
        int method = clampMethod(o.optInt("method", 5));
        int school = o.optInt("school", 0) == 1 ? 1 : 0;
        int preMinutes = o.optInt("preMinutes", 0);
        String timezone = o.optString("timezone", "");
        String city = o.optString("city", "");
        String country = o.optString("country", "");
        JSONObject adjustments = o.optJSONObject("adjustments");
        return new PrayerCalculationConfig(lat, lon, method, school, preMinutes,
                timezone, city, country, adjustments);
    }

    private static Double nullableDouble(JSONObject o, String key) {
        try {
            if (!o.has(key) || o.isNull(key)) return null;
            Object raw = o.get(key);
            if (raw == null) return null;
            String s = String.valueOf(raw).trim();
            if (s.isEmpty()) return null;
            double d = Double.parseDouble(s);
            return Double.isFinite(d) ? d : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static int clampMethod(int method) {
        return method >= 1 && method <= 5 ? method : 5;
    }

    private static String normalizeTimezone(String raw, String country) {
        String tz = raw == null ? "" : raw.trim();
        if (!tz.isEmpty()) {
            TimeZone candidate = TimeZone.getTimeZone(tz);
            // TimeZone silently returns GMT for unknown IDs. Accept GMT only when explicitly requested.
            if (!"GMT".equals(candidate.getID()) || "GMT".equalsIgnoreCase(tz) || tz.startsWith("Etc/GMT")) {
                return candidate.getID();
            }
        }
        String c = country == null ? "" : country.toLowerCase();
        if (c.contains("egypt") || c.contains("مصر")) return "Africa/Cairo";
        return TimeZone.getDefault().getID();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
