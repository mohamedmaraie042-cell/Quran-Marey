package com.mohamedmarey.quran;

/** Pure page-number helpers for the 604-page Madani mushaf navigation contract. */
public final class QuranPageLogic {
    public static final int FIRST_PAGE = 1;
    public static final int LAST_PAGE = 604;

    private QuranPageLogic() {}

    public static int clampPage(int page) {
        return Math.max(FIRST_PAGE, Math.min(LAST_PAGE, page));
    }

    public static boolean isValidPage(int page) {
        return page >= FIRST_PAGE && page <= LAST_PAGE;
    }
}
