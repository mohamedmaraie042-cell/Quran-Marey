package com.mohamedmarey.quran;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class PrayerWidgetProvider extends AppWidgetProvider {
    private static final String PREFS = "quran_marey_prayer_times_notification";
    private static final String KEY_JSON = "today_json";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_JSON, "");
        for (int id : appWidgetIds) updateOne(context, manager, id, json);
    }

    public static void updateAll(Context context, String json) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName provider = new ComponentName(context, PrayerWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(provider);
        for (int id : ids) updateOne(context, manager, id, json);
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id, String json) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_prayer);
        String next = "الصلاة القادمة";
        String nextTime = "--:--";
        String compact = "الفجر --:-- · الظهر --:-- · المغرب --:--";
        String location = "المسلم";
        try {
            JSONObject root = new JSONObject(json == null ? "" : json);
            JSONObject t = root.optJSONObject("timings");
            String nextName = root.optString("nextName", "").trim();
            nextTime = clean(root.optString("nextTime", "--:--"));
            if (!nextName.isEmpty()) next = "القادمة: " + nextName;
            location = root.optString("location", "المسلم").trim();
            if (location.isEmpty()) location = "المسلم";
            if (t != null) {
                compact = "الفجر " + clean(t.optString("Fajr", "--:--"))
                        + " · الظهر " + clean(t.optString("Dhuhr", "--:--"))
                        + " · المغرب " + clean(t.optString("Maghrib", "--:--"));
            }
        } catch (Exception ignored) {}

        views.setTextViewText(R.id.widgetNextPrayer, next);
        views.setTextViewText(R.id.widgetNextTime, nextTime);
        views.setTextViewText(R.id.widgetTimes, compact);
        views.setTextViewText(R.id.widgetLocation, location);

        Intent open = new Intent(context, MainActivity.class);
        open.putExtra("open_tab", "prayer");
        open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 7201, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widgetRoot, pi);
        manager.updateAppWidget(id, views);
    }

    private static String clean(String v) {
        if (v == null) return "--:--";
        String s = v.trim();
        int p = s.indexOf(' ');
        if (p > 0) s = s.substring(0, p);
        return s.isEmpty() ? "--:--" : s;
    }
}
