package com.mohamedmarey.quran;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Keeps a rolling native prayer schedule alive even when the UI is not opened for weeks. */
public class PrayerScheduleRenewReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Context app = context.getApplicationContext();
        try {
            PrayerAlarmScheduler.renewRollingSchedule(app);
            PrayerAlarmScheduler.scheduleRenewalCheck(app);
        } catch (Exception e) {
            CrashLogger.recordRuntime(app, "PrayerScheduleRenew", "فشل تجديد جدول الصلاة", e.toString());
        }

        final PendingResult pending = goAsync();
        new Thread(() -> {
            try { AdhanAudioCache.ensureAllCachedBlocking(app); }
            catch (Exception e) { CrashLogger.recordRuntime(app, "AdhanPrefetch", "فشل تجهيز ملفات الأذان المحلية", e.toString()); }
            finally { pending.finish(); }
        }, "PrayerRenewAdhanPrefetch").start();
    }
}
