package com.mohamedmarey.quran;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Offline prayer calculator used as a resilience fallback and by the rolling native scheduler.
 * Supports the five methods exposed by the UI and respects the selected time zone/DST.
 */
public final class LocalPrayerCalculator {
    private LocalPrayerCalculator() {}

    public static JSONArray generateSchedule(long nowMs, int days, PrayerCalculationConfig config) {
        JSONArray out = new JSONArray();
        if (config == null || !config.isUsable()) return out;
        TimeZone zone = TimeZone.getTimeZone(config.timezone);
        Calendar date = Calendar.getInstance(zone);
        date.setTimeInMillis(nowMs);
        date.set(Calendar.HOUR_OF_DAY, 12);
        date.set(Calendar.MINUTE, 0);
        date.set(Calendar.SECOND, 0);
        date.set(Calendar.MILLISECOND, 0);

        int count = Math.max(1, Math.min(45, days));
        for (int i = 0; i < count; i++) {
            if (i > 0) date.add(Calendar.DAY_OF_MONTH, 1);
            DayTimes times = calculateDay(date, config);
            if (times == null) continue;
            append(out, "صلاة الفجر", "Fajr", times.fajr, date, zone, nowMs, config.preMinutes);
            append(out, "صلاة الظهر", "Dhuhr", times.dhuhr, date, zone, nowMs, config.preMinutes);
            append(out, "صلاة العصر", "Asr", times.asr, date, zone, nowMs, config.preMinutes);
            append(out, "صلاة المغرب", "Maghrib", times.maghrib, date, zone, nowMs, config.preMinutes);
            append(out, "صلاة العشاء", "Isha", times.isha, date, zone, nowMs, config.preMinutes);
        }
        return out;
    }

    public static JSONObject calculateDayJson(int year, int monthZeroBased, int day,
                                              PrayerCalculationConfig config) {
        try {
            if (config == null || !config.isUsable()) return null;
            TimeZone zone = TimeZone.getTimeZone(config.timezone);
            Calendar c = Calendar.getInstance(zone);
            c.clear();
            c.set(year, monthZeroBased, day, 12, 0, 0);
            DayTimes t = calculateDay(c, config);
            if (t == null) return null;
            JSONObject timings = new JSONObject();
            timings.put("Fajr", format(t.fajr));
            timings.put("Sunrise", format(t.sunrise));
            timings.put("Dhuhr", format(t.dhuhr));
            timings.put("Asr", format(t.asr));
            timings.put("Maghrib", format(t.maghrib));
            timings.put("Isha", format(t.isha));
            JSONObject o = new JSONObject();
            o.put("timings", timings);
            o.put("timezone", config.timezone);
            o.put("method", config.method);
            return o;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static void append(JSONArray out, String name, String key, double hour,
                               Calendar date, TimeZone zone, long nowMs, int preMinutes) {
        if (!Double.isFinite(hour)) return;
        int[] hm = toHourMinute(hour);
        Calendar at = Calendar.getInstance(zone);
        at.clear();
        at.set(date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DAY_OF_MONTH), hm[0], hm[1], 0);
        long when = at.getTimeInMillis();
        if (!PrayerScheduleLogic.isFutureEnough(nowMs, when)) return;
        try {
            JSONObject item = new JSONObject();
            item.put("name", name);
            item.put("key", key);
            item.put("time", when);
            item.put("preMinutes", preMinutes);
            out.put(item);
        } catch (Exception ignored) {}
    }

    private static DayTimes calculateDay(Calendar date, PrayerCalculationConfig c) {
        double lat = c.lat;
        double lon = c.lon;
        if (!Double.isFinite(lat) || !Double.isFinite(lon)) return null;
        int year = date.get(Calendar.YEAR);
        int month = date.get(Calendar.MONTH) + 1;
        int day = date.get(Calendar.DAY_OF_MONTH);
        double jd = julian(year, month, day) - lon / (15d * 24d);
        double tz = timezoneHours(date, TimeZone.getTimeZone(c.timezone));
        MethodAngles angles = methodAngles(c.method);

        double fajr = tune(sunAngleTime(jd, lat, angles.fajrAngle, 5d / 24d, true), tz, lon);
        double sunrise = tune(sunAngleTime(jd, lat, 0.833d, 6d / 24d, true), tz, lon);
        double dhuhr = tune(midDay(jd, 12d / 24d), tz, lon);
        double asr = tune(asrTime(jd, lat, c.school == 1 ? 2d : 1d, 13d / 24d), tz, lon);
        double maghrib = tune(sunAngleTime(jd, lat, 0.833d, 18d / 24d, false), tz, lon);
        double isha = angles.ishaMinutesAfterMaghrib > 0
                ? fixHour(maghrib + angles.ishaMinutesAfterMaghrib / 60d)
                : tune(sunAngleTime(jd, lat, angles.ishaAngle, 18d / 24d, false), tz, lon);

        fajr = adjust(fajr, c.adjustments.optInt("Fajr", 0));
        sunrise = adjust(sunrise, c.adjustments.optInt("Sunrise", 0));
        dhuhr = adjust(dhuhr, c.adjustments.optInt("Dhuhr", 0));
        asr = adjust(asr, c.adjustments.optInt("Asr", 0));
        maghrib = adjust(maghrib, c.adjustments.optInt("Maghrib", 0));
        isha = adjust(isha, c.adjustments.optInt("Isha", 0));
        return new DayTimes(fajr, sunrise, dhuhr, asr, maghrib, isha);
    }

    private static MethodAngles methodAngles(int method) {
        switch (method) {
            case 1: return new MethodAngles(18d, 18d, 0);     // Karachi
            case 2: return new MethodAngles(15d, 15d, 0);     // ISNA
            case 3: return new MethodAngles(18d, 17d, 0);     // Muslim World League
            case 4: return new MethodAngles(18.5d, 0d, 90);   // Umm al-Qura
            case 5:
            default: return new MethodAngles(19.5d, 17.5d, 0); // Egyptian Survey Authority
        }
    }

    private static double timezoneHours(Calendar date, TimeZone zone) {
        Calendar noon = (Calendar) date.clone();
        noon.set(Calendar.HOUR_OF_DAY, 12);
        noon.set(Calendar.MINUTE, 0);
        noon.set(Calendar.SECOND, 0);
        noon.set(Calendar.MILLISECOND, 0);
        return zone.getOffset(noon.getTimeInMillis()) / 3600000d;
    }

    private static double tune(double time, double timezoneHours, double lon) {
        return time + (timezoneHours - lon / 15d);
    }

    private static double adjust(double hour, int minutes) {
        return fixHour(hour + Math.max(-30, Math.min(30, minutes)) / 60d);
    }

    private static String format(double hour) {
        int[] hm = toHourMinute(hour);
        return String.format(Locale.US, "%02d:%02d", hm[0], hm[1]);
    }

    private static int[] toHourMinute(double time) {
        time = fixHour(time + 0.5d / 60d);
        int h = (int) Math.floor(time);
        int m = (int) Math.floor((time - h) * 60d);
        if (m >= 60) { h = (h + 1) % 24; m = 0; }
        return new int[]{h, m};
    }

    private static double degToRad(double d) { return d * Math.PI / 180d; }
    private static double radToDeg(double r) { return r * 180d / Math.PI; }
    private static double fixAngle(double a) { a = a - 360d * Math.floor(a / 360d); return a < 0 ? a + 360d : a; }
    private static double fixHour(double a) { a = a - 24d * Math.floor(a / 24d); return a < 0 ? a + 24d : a; }
    private static double dSin(double d) { return Math.sin(degToRad(d)); }
    private static double dCos(double d) { return Math.cos(degToRad(d)); }
    private static double dTan(double d) { return Math.tan(degToRad(d)); }
    private static double dAsin(double x) { return radToDeg(Math.asin(x)); }
    private static double dAcos(double x) { return radToDeg(Math.acos(Math.max(-1d, Math.min(1d, x)))); }
    private static double dAtan2(double y, double x) { return radToDeg(Math.atan2(y, x)); }
    private static double arccot(double x) { return radToDeg(Math.atan2(1d, x)); }

    private static double julian(int y, int m, int d) {
        if (m <= 2) { y -= 1; m += 12; }
        int a = (int) Math.floor(y / 100d);
        int b = 2 - a + (int) Math.floor(a / 4d);
        return Math.floor(365.25d * (y + 4716)) + Math.floor(30.6001d * (m + 1)) + d + b - 1524.5d;
    }

    private static SunPosition sunPosition(double jd) {
        double d = jd - 2451545.0d;
        double g = fixAngle(357.529d + 0.98560028d * d);
        double q = fixAngle(280.459d + 0.98564736d * d);
        double l = fixAngle(q + 1.915d * dSin(g) + 0.020d * dSin(2d * g));
        double e = 23.439d - 0.00000036d * d;
        double ra = dAtan2(dCos(e) * dSin(l), dCos(l)) / 15d;
        ra = fixHour(ra);
        return new SunPosition(dAsin(dSin(e) * dSin(l)), q / 15d - ra);
    }

    private static double midDay(double jd, double t) { return fixHour(12d - sunPosition(jd + t).eq); }

    private static double sunAngleTime(double jd, double lat, double angle, double t, boolean ccw) {
        SunPosition sp = sunPosition(jd + t);
        double noon = midDay(jd, t);
        double num = -dSin(angle) - dSin(sp.decl) * dSin(lat);
        double den = dCos(sp.decl) * dCos(lat);
        double v = dAcos(num / den) / 15d;
        return noon + (ccw ? -v : v);
    }

    private static double asrTime(double jd, double lat, double factor, double t) {
        SunPosition sp = sunPosition(jd + t);
        double angle = -arccot(factor + dTan(Math.abs(lat - sp.decl)));
        return sunAngleTime(jd, lat, angle, t, false);
    }

    private static final class SunPosition {
        final double decl, eq;
        SunPosition(double decl, double eq) { this.decl = decl; this.eq = eq; }
    }

    private static final class MethodAngles {
        final double fajrAngle, ishaAngle;
        final int ishaMinutesAfterMaghrib;
        MethodAngles(double fajrAngle, double ishaAngle, int ishaMinutesAfterMaghrib) {
            this.fajrAngle = fajrAngle;
            this.ishaAngle = ishaAngle;
            this.ishaMinutesAfterMaghrib = ishaMinutesAfterMaghrib;
        }
    }

    private static final class DayTimes {
        final double fajr, sunrise, dhuhr, asr, maghrib, isha;
        DayTimes(double fajr, double sunrise, double dhuhr, double asr, double maghrib, double isha) {
            this.fajr = fajr; this.sunrise = sunrise; this.dhuhr = dhuhr;
            this.asr = asr; this.maghrib = maghrib; this.isha = isha;
        }
    }
}
