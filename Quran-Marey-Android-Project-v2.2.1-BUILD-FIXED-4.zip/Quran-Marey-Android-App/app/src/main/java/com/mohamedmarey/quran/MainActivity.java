package com.mohamedmarey.quran;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.Geocoder;
import android.location.Address;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.RecognizerIntent;
import android.speech.tts.UtteranceProgressListener;
import android.widget.Toast;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

import java.util.Locale;
import java.util.List;
import java.util.ArrayList;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech textToSpeech;
    private volatile boolean ttsReady = false;
    private static final int REQ_LOCATION = 1201;
    private static final int REQ_NOTIFICATIONS = 1202;
    private static final int REQ_VOICE = 1203;
    private LocationManager locationManager;
    private String pendingOpenTab = null;
    private WebViewAssetLoader assetLoader;

    @SuppressLint({"SetJavaScriptEnabled", "ObsoleteSdkInt"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLogger.install(this);
        pendingOpenTab = resolveOpenTab(getIntent());

        // Android 15/16: edge-to-edge is enforced for targetSdk 35+, so consume
        // system bar/cutout insets explicitly instead of relying on bar colors.
        WindowCompat.enableEdgeToEdge(getWindow());

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 240, 230));
        webView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        setContentView(webView);

        ViewCompat.setOnApplyWindowInsetsListener(webView, (view, insets) -> {
            Insets safe = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            return insets;
        });
        WindowInsetsControllerCompat bars = WindowCompat.getInsetsController(getWindow(), webView);
        bars.setAppearanceLightStatusBars(false);
        bars.setAppearanceLightNavigationBars(false);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(false);
        s.setSaveFormData(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) s.setSafeBrowsingEnabled(true);
        s.setUserAgentString(s.getUserAgentString() + " Al-Muslim/2.2.1");
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        // Respect the user's system font scale while keeping the responsive web layout stable.
        int textZoom = Math.round(getResources().getConfiguration().fontScale * 100f);
        s.setTextZoom(Math.max(100, Math.min(170, textZoom)));

        initTextToSpeech();
        webView.addJavascriptInterface(new AndroidBridge(), "QuranAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse response = assetLoader.shouldInterceptRequest(request.getUrl());
                return response != null ? response : super.shouldInterceptRequest(view, request);
            }

            @Override
            @SuppressWarnings("deprecation")
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                WebResourceResponse response = assetLoader.shouldInterceptRequest(Uri.parse(url));
                return response != null ? response : super.shouldInterceptRequest(view, url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternalIfNeeded(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalIfNeeded(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                deliverOpenTab();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request != null && request.isForMainFrame()) {
                    String msg = error == null ? "WebView main-frame error" : String.valueOf(error.getDescription());
                    CrashLogger.recordRuntime(MainActivity.this, "WebView", msg, request.getUrl() == null ? "" : request.getUrl().toString());
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                if (cm != null) {
                    String message = cm.message() == null ? "" : cm.message();
                    String lower = message.toLowerCase(Locale.US);
                    if (lower.contains("uncaught") || lower.contains("typeerror") || lower.contains("referenceerror") || lower.contains("syntaxerror")) {
                        CrashLogger.recordRuntime(MainActivity.this, "JavaScript console", message, cm.sourceId() + ":" + cm.lineNumber());
                    }
                }
                return super.onConsoleMessage(cm);
            }
        });

        FcmRegistration.ensureSubscribed(this);
        AdhanAudioCache.ensureAllCachedAsync(this);
        registerPredictiveBack();
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private boolean openExternalIfNeeded(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme();
        if (scheme == null || "about".equalsIgnoreCase(scheme)) return false;
        if ("https".equalsIgnoreCase(scheme)
                && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())) {
            return false;
        }
        if ("https".equalsIgnoreCase(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
            }
            return true;
        }
        // Never navigate the embedded WebView to cleartext or unknown schemes.
        return true;
    }

    private void initTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                ttsReady = false;
                notifyTtsState("error", "تعذر تشغيل محرك النطق في الهاتف.");
                return;
            }

            int result = textToSpeech.setLanguage(new Locale("ar", "SA"));
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
            textToSpeech.setSpeechRate(0.88f);

            if (ttsReady) {
                notifyTtsState("ready", "محرك النطق العربي جاهز.");
            } else {
                notifyTtsState("error", "اللغة العربية غير متاحة في محرك النطق على الهاتف.");
            }
        });

        textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                notifyTtsState("start", "جاري قراءة التفسير صوتيًا...");
            }

            @Override
            public void onDone(String utteranceId) {
                notifyTtsState("done", "انتهت قراءة التفسير.");
            }

            @Override
            public void onError(String utteranceId) {
                notifyTtsState("error", "تعذر تشغيل قراءة التفسير صوتيًا.");
            }
        });
    }

    private void notifyTtsState(String state, String message) {
        if (webView == null) return;
        final String js = "window.onNativeTtsState && window.onNativeTtsState("
                + jsQuote(state) + "," + jsQuote(message) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private static String jsQuote(String value) {
        if (value == null) return "null";
        return "\"" + value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r") + "\"";
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void copyToClipboard(String text) {
            if (text == null) return;
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    clipboard.setPrimaryClip(ClipData.newPlainText("Quran Marey", text));
                }
            });
        }

        @JavascriptInterface
        public boolean isTtsReady() {
            return ttsReady;
        }

        @JavascriptInterface
        public void speakArabic(String text) {
            if (text == null || text.trim().isEmpty()) return;
            runOnUiThread(() -> {
                if (!ttsReady || textToSpeech == null) {
                    notifyTtsState("error", "محرك النطق العربي غير جاهز على الهاتف.");
                    return;
                }
                String utteranceId = "tafsir-" + System.currentTimeMillis();
                int result = textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
                if (result == TextToSpeech.ERROR) {
                    notifyTtsState("error", "تعذر بدء قراءة التفسير صوتيًا.");
                }
            });
        }

        @JavascriptInterface
        public void stopTts() {
            runOnUiThread(() -> {
                if (textToSpeech != null) textToSpeech.stop();
                notifyTtsState("stopped", "تم إيقاف صوت التفسير.");
            });
        }

        @JavascriptInterface
        public void setPrayerTimesNotificationEnabled(boolean enabled) {
            runOnUiThread(() -> {
                PrayerTimesNotificationManager.setEnabled(MainActivity.this, enabled);
                if (enabled && Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                }
            });
        }

        @JavascriptInterface
        public boolean isPrayerTimesNotificationEnabled() {
            return PrayerTimesNotificationManager.isEnabled(MainActivity.this);
        }

        @JavascriptInterface
        public void updatePrayerTimesNotification(String json) {
            runOnUiThread(() -> PrayerTimesNotificationManager.updateFromJson(MainActivity.this, json));
        }

        @JavascriptInterface
        public void setAdhanEnabled(boolean enabled) {
            runOnUiThread(() -> {
                PrayerAlarmScheduler.setEnabled(MainActivity.this, enabled);
                if (enabled && Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                }
                notifyAdhanState(enabled ? "enabled" : "disabled",
                        enabled ? "تم تفعيل الأذان. سيتم تشغيله في المواقيت المجدولة." : "تم إيقاف الأذان وإلغاء التنبيهات المجدولة.");
            });
        }

        @JavascriptInterface
        public boolean isAdhanEnabled() {
            return PrayerAlarmScheduler.isEnabled(MainActivity.this);
        }

        @JavascriptInterface
        public void schedulePrayerAlarms(String json) {
            runOnUiThread(() -> {
                int count = PrayerAlarmScheduler.scheduleFromJson(MainActivity.this, json);
                notifyAdhanState("scheduled", "تمت جدولة " + count + " صلاة قادمة على الهاتف.");
            });
        }

        @JavascriptInterface
        public boolean savePrayerCalculationConfig(String json) {
            return PrayerAlarmScheduler.saveCalculationConfig(MainActivity.this, json);
        }

        @JavascriptInterface
        public String exportNativePreferences() {
            return AppSettingsBackup.exportJson(MainActivity.this);
        }

        @JavascriptInterface
        public boolean importNativePreferences(String json) {
            return AppSettingsBackup.importJson(MainActivity.this, json);
        }

        @JavascriptInterface
        public void previewAdhan() {
            runOnUiThread(() -> {
                try {
                    Intent service = new Intent(MainActivity.this, AdhanService.class);
                    service.setAction(AdhanService.ACTION_PLAY);
                    service.putExtra("prayer_name", "الصلاة");
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
                    else startService(service);
                } catch (Exception e) {
                    CrashLogger.recordRuntime(MainActivity.this, "AdhanPreview", "تعذر بدء اختبار الأذان", e.toString());
                    notifyAdhanState("error", "تعذر بدء اختبار الأذان. راجع صلاحيات الإشعارات والبطارية.");
                }
            });
        }

        @JavascriptInterface
        public void stopAdhan() {
            runOnUiThread(() -> {
                try {
                    Intent service = new Intent(MainActivity.this, AdhanService.class);
                    service.setAction(AdhanService.ACTION_STOP);
                    startService(service);
                } catch (Exception e) {
                    stopService(new Intent(MainActivity.this, AdhanService.class));
                }
            });
        }

        @JavascriptInterface
        public void setAdhanVoice(String voice) {
            AdhanPreferences.setVoice(MainActivity.this, voice);
            AdhanAudioCache.ensureCachedAsync(MainActivity.this, voice, null);
            notifyAdhanState("voice", "تم اختيار صوت الأذان وجاري التأكد من توفره محليًا.");
        }

        @JavascriptInterface
        public void setPrayerAdhanPreference(String prayerKey, String voice, String mode) {
            AdhanPreferences.setPrayerVoice(MainActivity.this, prayerKey, voice);
            AdhanPreferences.setPrayerMode(MainActivity.this, prayerKey, mode);
            AdhanAudioCache.ensureCachedAsync(MainActivity.this, voice, null);
            notifyAdhanState("prayer_voice", "تم حفظ إعداد أذان الصلاة.");
        }

        @JavascriptInterface
        public String getPrayerAdhanPreference(String prayerKey) {
            String voice = AdhanPreferences.getPrayerVoice(MainActivity.this, prayerKey);
            String mode = AdhanPreferences.getPrayerMode(MainActivity.this, prayerKey);
            return "{\"voice\":" + jsQuote(voice) + ",\"mode\":" + jsQuote(mode) + "}";
        }

        @JavascriptInterface
        public String getAdhanVoice() {
            return AdhanPreferences.getVoice(MainActivity.this);
        }

        @JavascriptInterface
        public boolean canScheduleExactAlarms() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
            android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        }

        @JavascriptInterface
        public boolean canUseFullScreenAdhan() {
            if (Build.VERSION.SDK_INT < 34) return true;
            android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
            return nm != null && nm.canUseFullScreenIntent();
        }

        @JavascriptInterface
        public void openAdhanPermissions() {
            runOnUiThread(MainActivity.this::openAdhanPermissionSettings);
        }

        @JavascriptInterface
        public void requestLocation() {
            runOnUiThread(MainActivity.this::requestPrayerLocation);
        }

        @JavascriptInterface
        public void openLocationSettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface
        public boolean isLocationEnabled() {
            try {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (lm == null) return false;
                boolean gps = false;
                boolean network = false;
                try { gps = lm.isProviderEnabled(LocationManager.GPS_PROVIDER); } catch (Exception ignored) {}
                try { network = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER); } catch (Exception ignored) {}
                return gps || network;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String getLocationPermissionState() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return "coarse";
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) return "coarse";
            return "none";
        }

        @JavascriptInterface
        public boolean isBatteryOptimizationIgnored() {
            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void openBatteryOptimizationSettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                } catch (Exception e) {
                    try {
                        Intent details = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                        startActivity(details);
                    } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface
        public void requestPrayerTimes(String url, String requestId) {
            final String safeUrl = url == null ? "" : url.trim();
            final String safeId = requestId == null ? "" : requestId.trim();
            new Thread(() -> {
                HttpURLConnection conn = null;
                try {
                    if (!NetworkPolicy.isAllowedPrayerApiUrl(safeUrl)) {
                        notifyPrayerResponse(safeId, false, "رابط خدمة المواقيت غير مسموح.");
                        return;
                    }
                    conn = (HttpURLConnection) new URL(safeUrl).openConnection();
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(12000);
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setRequestProperty("User-Agent", "Al-Muslim-Android/2.2.0");
                    int code = conn.getResponseCode();
                    if (code < 200 || code >= 300) {
                        notifyPrayerResponse(safeId, false, "تعذر تحميل المواقيت من الخادم (" + code + ").");
                        return;
                    }
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder out = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) out.append(line);
                    reader.close();
                    notifyPrayerResponse(safeId, true, out.toString());
                } catch (Exception e) {
                    notifyPrayerResponse(safeId, false, "تعذر الاتصال بخدمة مواقيت الصلاة.");
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }, "PrayerTimesFetch").start();
        }

        @JavascriptInterface
        public void configureSmartReminders(String json) {
            runOnUiThread(() -> {
                SmartReminderScheduler.configure(MainActivity.this, json);
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                }
                Toast.makeText(MainActivity.this, "تم حفظ إعدادات التذكيرات", Toast.LENGTH_SHORT).show();
            });
        }

        @JavascriptInterface
        public void startVoiceCommand() {
            runOnUiThread(MainActivity.this::launchVoiceRecognition);
        }

        @JavascriptInterface
        public void shareText(String title, String text) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "المسلم" : title);
                    send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    startActivity(Intent.createChooser(send, "مشاركة من تطبيق المسلم"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر فتح المشاركة", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void openNearbyMosques(double lat, double lon) {
            runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse("geo:" + lat + "," + lon + "?q=" + Uri.encode("مسجد"));
                    Intent map = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(map);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "لا يوجد تطبيق خرائط متاح", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public String getLastCrashLog() {
            return CrashLogger.getCombined(MainActivity.this);
        }

        @JavascriptInterface
        public void reportRuntimeError(String source, String message, String details) {
            CrashLogger.recordRuntime(MainActivity.this, source, message, details);
        }

        @JavascriptInterface
        public void clearCrashLog() {
            CrashLogger.clear(MainActivity.this);
        }

        @JavascriptInterface
        public String getAppVersion() {
            return "2.2.0";
        }

        @JavascriptInterface
        public void playQuranInBackground(String url, String title, String subtitle, String prevUrl, String nextUrl) {
            final String safePrev = NetworkPolicy.isAllowedQuranAudioUrl(prevUrl) ? prevUrl : "";
            final String safeNext = NetworkPolicy.isAllowedQuranAudioUrl(nextUrl) ? nextUrl : "";
            runOnUiThread(() -> {
                try {
                    if (!NetworkPolicy.isAllowedQuranAudioUrl(url)) {
                        Toast.makeText(MainActivity.this, "مصدر التلاوة غير مسموح", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Intent i = new Intent(MainActivity.this, QuranAudioService.class);
                    i.setAction(QuranAudioService.ACTION_PLAY_URL);
                    i.putExtra("url", url);
                    i.putExtra("title", title);
                    i.putExtra("subtitle", subtitle);
                    i.putExtra("prev_url", safePrev);
                    i.putExtra("next_url", safeNext);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
                } catch (Exception e) {
                    CrashLogger.recordRuntime(MainActivity.this, "QuranAudio", "تعذر بدء مشغل الخلفية", e.toString());
                    Toast.makeText(MainActivity.this, "تعذر تشغيل القرآن في الخلفية", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void stopQuranBackground() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(MainActivity.this, QuranAudioService.class);
                    i.setAction(QuranAudioService.ACTION_STOP);
                    startService(i);
                } catch (Exception e) {
                    CrashLogger.recordRuntime(MainActivity.this, "QuranAudio", "تعذر إيقاف مشغل الخلفية", e.toString());
                    stopService(new Intent(MainActivity.this, QuranAudioService.class));
                }
            });
        }

        @JavascriptInterface
        public void setDownloadWifiOnly(boolean wifiOnly) {
            getSharedPreferences("al_muslim_downloads", Context.MODE_PRIVATE).edit().putBoolean("wifi_only", wifiOnly).apply();
        }

        @JavascriptInterface
        public boolean getDownloadWifiOnly() {
            return getSharedPreferences("al_muslim_downloads", Context.MODE_PRIVATE).getBoolean("wifi_only", false);
        }

        @JavascriptInterface
        public void downloadAudio(String url, String fileName) {
            runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(url == null ? "" : url.trim());
                    if (!NetworkPolicy.isAllowedQuranAudioUrl(uri.toString())) {
                        notifyDownloadState("error", "مصدر التنزيل غير مسموح أو غير آمن.", "");
                        return;
                    }

                    String safeName = sanitizeFileName(fileName);
                    if (safeName.isEmpty()) safeName = "quran-audio.mp3";
                    if (!safeName.toLowerCase(Locale.US).endsWith(".mp3")) safeName += ".mp3";

                    DownloadManager.Request request = new DownloadManager.Request(uri);
                    request.setTitle(safeName.replace(".mp3", ""));
                    request.setDescription("Quran Marey - تلاوة القرآن الكريم");
                    request.setMimeType("audio/mpeg");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    boolean wifiOnly = getSharedPreferences("al_muslim_downloads", Context.MODE_PRIVATE).getBoolean("wifi_only", false);
                    request.setAllowedOverMetered(!wifiOnly);
                    request.setAllowedOverRoaming(false);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "QuranMarey/" + safeName);
                    } else {
                        request.setDestinationInExternalFilesDir(MainActivity.this, Environment.DIRECTORY_MUSIC, "QuranMarey/" + safeName);
                    }

                    DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (manager == null) {
                        notifyDownloadState("error", "خدمة التنزيل غير متاحة على الهاتف.", safeName);
                        return;
                    }

                    long id = manager.enqueue(request);
                    Toast.makeText(MainActivity.this, "بدأ تنزيل التلاوة", Toast.LENGTH_SHORT).show();
                    notifyDownloadState("started", "بدأ تنزيل التلاوة. سيظهر إشعار عند اكتمالها ويمكن العثور عليها داخل مجلد QuranMarey.", safeName + "#" + id);
                } catch (Exception e) {
                    notifyDownloadState("error", "تعذر بدء تنزيل التلاوة.", "");
                }
            });
        }
    }

    private void launchVoiceRecognition() {
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "قل: افتح سورة يس، مواقيت الصلاة، أذكار الصباح...");
            startActivityForResult(intent, REQ_VOICE);
        } catch (Exception e) {
            notifyVoiceCommand("");
            Toast.makeText(this, "التعرف الصوتي غير متاح على الهاتف", Toast.LENGTH_SHORT).show();
        }
    }

    private void notifyVoiceCommand(String text) {
        if (webView == null) return;
        final String js = "window.onNativeVoiceCommand && window.onNativeVoiceCommand(" + jsQuote(text) + ");";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private String resolveOpenTab(Intent intent) {
        if (intent == null) return null;
        String tab = intent.getStringExtra("open_tab");
        if (tab != null && !tab.trim().isEmpty()) return tab.trim();
        Uri data = intent.getData();
        if (data != null && "almuslim".equalsIgnoreCase(data.getScheme())) {
            String q = data.getQueryParameter("tab");
            if (q != null && !q.trim().isEmpty()) return q.trim();
            if (data.getPathSegments() != null && !data.getPathSegments().isEmpty()) return data.getPathSegments().get(0);
        }
        return null;
    }

    private void deliverOpenTab() {
        if (webView == null || pendingOpenTab == null || pendingOpenTab.trim().isEmpty()) return;
        String tab = pendingOpenTab;
        pendingOpenTab = null;
        webView.evaluateJavascript("window.openFromNative && window.openFromNative(" + jsQuote(tab) + ");", null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        pendingOpenTab = resolveOpenTab(intent);
        deliverOpenTab();
    }

    private void openAdhanPermissionSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (am != null && !am.canScheduleExactAlarms()) {
                    Intent exact = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(exact);
                    notifyAdhanState("permission", "فعّل السماح بالتنبيهات الدقيقة، ثم ارجع للتطبيق واضغط الزر مرة أخرى.");
                    return;
                }
            }
            if (Build.VERSION.SDK_INT >= 34) {
                android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
                if (nm != null && !nm.canUseFullScreenIntent()) {
                    Intent full = new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT",
                            Uri.parse("package:" + getPackageName()));
                    startActivity(full);
                    notifyAdhanState("permission", "اسمح للتطبيق بعرض تنبيه ملء الشاشة وقت الأذان.");
                    return;
                }
            }
            notifyAdhanState("permission_ready", "✅ إعدادات الأذان المهمة مفعّلة على الهاتف.");
        } catch (Exception e) {
            try {
                Intent details = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(details);
            } catch (Exception ignored) {}
        }
    }

    private void notifyAdhanState(String state, String message) {
        if (webView == null) return;
        final String js = "window.onNativeAdhanState && window.onNativeAdhanState("
                + jsQuote(state) + "," + jsQuote(message) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void notifyPrayerResponse(String requestId, boolean ok, String payload) {
        if (webView == null) return;
        final String js = "window.onNativePrayerTimes && window.onNativePrayerTimes("
                + jsQuote(requestId) + "," + (ok ? "true" : "false") + "," + jsQuote(payload) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void notifyLocation(Location location) {
        if (webView == null || location == null) return;
        final float accuracy = location.hasAccuracy() ? location.getAccuracy() : -1f;
        final String provider = location.getProvider() == null ? "" : location.getProvider();
        final long fixTime = location.getTime();
        final String js = "window.onNativeLocation && window.onNativeLocation("
                + location.getLatitude() + "," + location.getLongitude() + "," + accuracy + ","
                + jsQuote(provider) + "," + fixTime + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
        resolveLocationName(location);
    }

    private void resolveLocationName(Location location) {
        if (location == null || !Geocoder.isPresent()) return;
        new Thread(() -> {
            try {
                Geocoder geocoder = new Geocoder(MainActivity.this, new Locale("ar", "EG"));
                @SuppressWarnings("deprecation")
                List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                if (addresses == null || addresses.isEmpty()) return;
                Address a = addresses.get(0);
                String city = firstNonEmpty(a.getLocality(), a.getSubAdminArea(), a.getAdminArea());
                String area = firstNonEmpty(a.getSubLocality(), a.getAdminArea());
                String country = firstNonEmpty(a.getCountryName(), a.getCountryCode());
                String label;
                if (!city.isEmpty() && !area.isEmpty() && !city.equals(area)) label = city + "، " + area;
                else label = !city.isEmpty() ? city : area;
                if (!country.isEmpty() && !label.isEmpty()) label += "، " + country;
                else if (!country.isEmpty()) label = country;
                notifyLocationDetails(label, city, country);
            } catch (Exception ignored) {}
        }, "LocationGeocoder").start();
    }

    private static String firstNonEmpty(String... values) {
        if (values == null) return "";
        for (String v : values) {
            if (v != null && !v.trim().isEmpty()) return v.trim();
        }
        return "";
    }

    private void notifyLocationDetails(String label, String city, String country) {
        if (webView == null) return;
        final String js = "window.onNativeLocationDetails && window.onNativeLocationDetails("
                + jsQuote(label) + "," + jsQuote(city) + "," + jsQuote(country) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void notifyLocationError(String message) {
        if (webView == null) return;
        final String js = "window.onNativeLocationError && window.onNativeLocationError(" + jsQuote(message) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void requestPrayerLocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        fetchPrayerLocation();
    }

    @SuppressLint("MissingPermission")
    private void fetchPrayerLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (locationManager == null) {
                notifyLocationError("خدمة الموقع غير متاحة على الهاتف.");
                return;
            }

            boolean gpsEnabled = false;
            boolean networkEnabled = false;
            try { gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER); } catch (Exception ignored) {}
            try { networkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER); } catch (Exception ignored) {}

            Location best = null;
            String[] providers = new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
            for (String provider : providers) {
                try {
                    Location loc = locationManager.getLastKnownLocation(provider);
                    if (loc == null) continue;
                    if (best == null) best = loc;
                    else {
                        boolean newer = loc.getTime() > best.getTime();
                        boolean moreAccurate = loc.hasAccuracy() && (!best.hasAccuracy() || loc.getAccuracy() < best.getAccuracy());
                        if (newer || moreAccurate) best = loc;
                    }
                } catch (Exception ignored) {}
            }

            final Location fallback = best;
            final long age = fallback == null ? Long.MAX_VALUE : Math.max(0L, System.currentTimeMillis() - fallback.getTime());
            if (fallback != null && age < 15L * 60L * 1000L && (!fallback.hasAccuracy() || fallback.getAccuracy() <= 2500f)) {
                notifyLocation(fallback);
                return;
            }

            if (!gpsEnabled && !networkEnabled) {
                if (fallback != null) {
                    notifyLocation(fallback);
                    notifyLocationError("تم استخدام آخر موقع محفوظ. فعّل GPS للحصول على موقع أحدث.");
                } else {
                    notifyLocationError("خدمة الموقع مقفولة. اضغط «تشغيل الموقع» ثم ارجع واضغط «موقعي تلقائيًا».");
                }
                return;
            }

            final boolean[] delivered = {false};
            LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    if (location == null || delivered[0]) return;
                    delivered[0] = true;
                    notifyLocation(location);
                    try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
                }
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            };

            boolean requested = false;
            if (networkEnabled) {
                try {
                    locationManager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, listener, Looper.getMainLooper());
                    requested = true;
                } catch (Exception ignored) {}
            }
            if (gpsEnabled) {
                try {
                    locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, listener, Looper.getMainLooper());
                    requested = true;
                } catch (Exception ignored) {}
            }

            if (!requested) {
                if (fallback != null) notifyLocation(fallback);
                else notifyLocationError("تعذر بدء تحديد الموقع. افتح إعدادات الموقع وحاول مرة أخرى.");
                return;
            }

            if (webView != null) {
                webView.postDelayed(() -> {
                    if (delivered[0]) return;
                    delivered[0] = true;
                    if (fallback != null) notifyLocation(fallback);
                    else notifyLocationError("لم يصل موقع من الهاتف خلال 12 ثانية. جرّب في مكان مفتوح أو اختر منطقتك من القائمة.");
                    try { locationManager.removeUpdates(listener); } catch (Exception ignored) {}
                }, 12000L);
            }
        } catch (SecurityException e) {
            notifyLocationError("إذن الموقع غير متاح. اسمح بالموقع من إعدادات التطبيق ثم حاول مرة أخرى.");
        } catch (Exception e) {
            notifyLocationError("تعذر الوصول إلى الموقع. يمكنك اختيار منطقتك من القائمة بدلًا من الكتابة.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VOICE) {
            String text = "";
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (list != null && !list.isEmpty()) text = list.get(0);
            }
            notifyVoiceCommand(text);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int result : grantResults) {
                if (result == PackageManager.PERMISSION_GRANTED) { granted = true; break; }
            }
            if (granted) fetchPrayerLocation();
            else notifyLocationError("تم رفض إذن الموقع. اسمح بالموقع من إعدادات التطبيق أو اختر منطقتك من القائمة.");
        } else if (requestCode == REQ_NOTIFICATIONS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) PrayerTimesNotificationManager.restore(this);
            notifyAdhanState(granted ? "notification_ready" : "notification_denied",
                    granted ? "تم السماح بإشعارات الصلاة ومواقيت اليوم." : "إذن الإشعارات مرفوض؛ الأذان وإشعار المواقيت الدائم قد لا يظهرا.");
        }
    }

    private static String sanitizeFileName(String value) {
        if (value == null) return "";
        return value.replaceAll("[\\/:*?\"<>|\n\r\t]", "-").trim();
    }

    private void notifyDownloadState(String state, String message, String data) {
        if (webView == null) return;
        final String js = "window.onNativeDownloadState && window.onNativeDownloadState("
                + jsQuote(state) + "," + jsQuote(message) + "," + jsQuote(data) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void registerPredictiveBack() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    this::handleBackNavigation);
        }
    }

    private void handleBackNavigation() {
        if (webView == null) {
            finishAfterTransition();
            return;
        }
        webView.evaluateJavascript(
                "window.handleAndroidBack ? window.handleAndroidBack() : false",
                value -> {
                    if (!"true".equalsIgnoreCase(String.valueOf(value))) {
                        if (webView != null && webView.canGoBack()) webView.goBack();
                        else finishAfterTransition();
                    }
                });
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) handleBackNavigation();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("QuranAndroid");
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
