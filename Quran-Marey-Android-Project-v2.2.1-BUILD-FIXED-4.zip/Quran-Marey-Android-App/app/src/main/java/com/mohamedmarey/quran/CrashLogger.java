package com.mohamedmarey.quran;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class CrashLogger {
    private static final String PREFS = "al_muslim_diagnostics";
    private static final String KEY = "last_crash";
    private static final String RUNTIME_KEY = "last_runtime_error";
    private static Thread.UncaughtExceptionHandler previous;

    private CrashLogger() {}

    public static void install(Context context) {
        if (previous != null) return;
        previous = Thread.getDefaultUncaughtExceptionHandler();
        Context app = context.getApplicationContext();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                StringWriter sw = new StringWriter();
                error.printStackTrace(new PrintWriter(sw));
                String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
                String text = stamp + "\n" + error.getClass().getName() + ": " + error.getMessage() + "\n" + sw;
                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, text).apply();
            } catch (Exception ignored) {}
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    public static String get(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "");
    }

    public static void recordRuntime(Context context, String source, String message, String details) {
        try {
            String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
            StringBuilder out = new StringBuilder();
            out.append(stamp).append("\n");
            if (source != null && !source.trim().isEmpty()) out.append(source.trim()).append(": ");
            out.append(message == null ? "Runtime error" : message.trim());
            if (details != null && !details.trim().isEmpty()) out.append("\n").append(details.trim());
            context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(RUNTIME_KEY, out.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static String getRuntime(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(RUNTIME_KEY, "");
    }

    public static String getCombined(Context context) {
        String crash = get(context);
        String runtime = getRuntime(context);
        if (crash.isEmpty()) return runtime;
        if (runtime.isEmpty()) return crash;
        return "[Crash]\n" + crash + "\n\n[Runtime]\n" + runtime;
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).remove(RUNTIME_KEY).apply();
    }
}
