package com.mohamedmarey.quran;

import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;

/** Registers normal user installs for server-side admin announcements. */
public final class FcmRegistration {
    public static final String TOPIC = "all_users";

    private FcmRegistration() {}

    public static void ensureSubscribed(Context context) {
        try {
            if (FirebaseApp.getApps(context).isEmpty() && FirebaseApp.initializeApp(context) == null) {
                // Production Firebase config has not been added yet. Do not crash the app.
                return;
            }
            FirebaseMessaging.getInstance().subscribeToTopic(TOPIC);
        } catch (Exception e) {
            CrashLogger.recordRuntime(context, "FCM", "تعذر تسجيل الجهاز في إشعارات الإدارة", e.toString());
        }
    }
}
