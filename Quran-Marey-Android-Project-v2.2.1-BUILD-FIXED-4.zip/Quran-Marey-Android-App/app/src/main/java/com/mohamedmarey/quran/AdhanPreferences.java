package com.mohamedmarey.quran;

import android.content.Context;
import android.content.SharedPreferences;

public final class AdhanPreferences {
    private static final String PREFS = "quran_marey_adhan_prefs";
    private static final String KEY_VOICE = "adhan_voice";
    private static final String DEFAULT_VOICE = "afasy";

    private AdhanPreferences() {}

    public static void setVoice(Context context, String voice) {
        prefs(context).edit().putString(KEY_VOICE, normalizeVoice(voice)).apply();
    }

    public static String getVoice(Context context) {
        return normalizeVoice(prefs(context).getString(KEY_VOICE, DEFAULT_VOICE));
    }

    public static void setPrayerVoice(Context context, String prayerKey, String voice) {
        prefs(context).edit().putString("voice_" + normalizePrayerKey(prayerKey), normalizeVoice(voice)).apply();
    }

    public static String getPrayerVoice(Context context, String prayerNameOrKey) {
        String key = normalizePrayerKey(prayerNameOrKey);
        return normalizeVoice(prefs(context).getString("voice_" + key, getVoice(context)));
    }

    public static void setPrayerMode(Context context, String prayerKey, String mode) {
        prefs(context).edit().putString("mode_" + normalizePrayerKey(prayerKey), normalizeMode(mode)).apply();
    }

    public static String getPrayerMode(Context context, String prayerNameOrKey) {
        String key = normalizePrayerKey(prayerNameOrKey);
        return normalizeMode(prefs(context).getString("mode_" + key, "full"));
    }

    private static String normalizeVoice(String voice) {
        // User requirement: recorded adhan only. No TTS/AI/fallback voices.
        if ("qatami".equals(voice)) return "qatami";
        return DEFAULT_VOICE;
    }

    private static String normalizeMode(String mode) {
        if ("full".equals(mode) || "short".equals(mode) || "silent".equals(mode)) return mode;
        return "full";
    }

    private static String normalizePrayerKey(String value) {
        String s = value == null ? "" : value.toLowerCase();
        if (s.contains("fajr") || s.contains("الفجر")) return "fajr";
        if (s.contains("dhuhr") || s.contains("ظهر") || s.contains("الظهر")) return "dhuhr";
        if (s.contains("asr") || s.contains("عصر") || s.contains("العصر")) return "asr";
        if (s.contains("maghrib") || s.contains("مغرب") || s.contains("المغرب")) return "maghrib";
        if (s.contains("isha") || s.contains("عشاء") || s.contains("العشاء")) return "isha";
        return "default";
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
