package com.mohamedmarey.quran;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PrayerNotificationRefreshReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        try { PrayerTimesNotificationManager.restore(context); }
        catch (Exception e) { CrashLogger.recordRuntime(context, "PrayerNotificationRefresh", "فشل تحديث إشعار المواقيت", e.toString()); }
    }
}
