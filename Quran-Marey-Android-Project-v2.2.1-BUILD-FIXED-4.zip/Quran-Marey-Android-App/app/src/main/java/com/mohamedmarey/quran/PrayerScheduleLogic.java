package com.mohamedmarey.quran;

/** Pure scheduling helpers kept Android-free so they can be regression-tested on the JVM. */
public final class PrayerScheduleLogic {
    private PrayerScheduleLogic() {}

    public static int clampPreMinutes(int value) {
        return Math.max(0, Math.min(120, value));
    }

    public static boolean isFutureEnough(long nowMs, long whenMs) {
        return whenMs > nowMs + 15_000L;
    }

    public static int requestCode(String prayer, long whenMs) {
        long minutes = whenMs / 60_000L;
        return (int) ((minutes ^ String.valueOf(prayer).hashCode()) & 0x7fffffff);
    }
}
