package com.mohamedmarey.quran;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Downloads the two allowed recorded adhans ahead of time and plays from local storage. */
public final class AdhanAudioCache {
    private static final String URL_AFASY = "https://download.tvquran.com/download/TvQuran.com__Athan/TvQuran.com__04.athan.mp3";
    private static final String URL_QATAMI = "https://download.tvquran.com/download/TvQuran.com__Athan/TvQuran.com__08.athan.mp3";
    private static final long MIN_VALID_BYTES = 100_000L;
    private static final long MAX_BYTES = 15L * 1024L * 1024L;

    private AdhanAudioCache() {}

    public interface Callback { void onReady(boolean ready, File file); }

    public static File cachedFile(Context context, String voice) {
        File dir = new File(context.getFilesDir(), "adhan-cache");
        return new File(dir, normalizeVoice(voice) + ".mp3");
    }

    public static boolean isCached(Context context, String voice) {
        return isValid(cachedFile(context, voice));
    }

    public static void ensureAllCachedAsync(Context context) {
        Context app = context.getApplicationContext();
        new Thread(() -> ensureAllCachedBlocking(app), "AdhanPrefetch").start();
    }

    static void ensureAllCachedBlocking(Context context) {
        Context app = context.getApplicationContext();
        ensureCachedBlocking(app, "afasy");
        ensureCachedBlocking(app, "qatami");
    }

    public static void ensureCachedAsync(Context context, String voice, Callback callback) {
        Context app = context.getApplicationContext();
        String normalized = normalizeVoice(voice);
        new Thread(() -> {
            File file = ensureCachedBlocking(app, normalized);
            if (callback != null) {
                new Handler(Looper.getMainLooper()).post(() -> callback.onReady(isValid(file), file));
            }
        }, "AdhanCache-" + normalized).start();
    }

    private static File ensureCachedBlocking(Context context, String voice) {
        File target = cachedFile(context, voice);
        if (isValid(target)) return target;
        String url = "qatami".equals(normalizeVoice(voice)) ? URL_QATAMI : URL_AFASY;
        if (!NetworkPolicy.isAllowedAdhanUrl(url)) return target;
        File dir = target.getParentFile();
        if (dir != null && !dir.exists() && !dir.mkdirs()) return target;
        File temp = new File(target.getAbsolutePath() + ".part");
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(12_000);
            conn.setReadTimeout(35_000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "Al-Muslim-Android/2.2.1");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) return target;
            if (!NetworkPolicy.isAllowedAdhanUrl(conn.getURL().toString())) return target;
            long declared = conn.getContentLengthLong();
            if (declared > MAX_BYTES) return target;

            long total = 0L;
            byte[] buffer = new byte[16 * 1024];
            try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
                 FileOutputStream out = new FileOutputStream(temp, false)) {
                int n;
                while ((n = in.read(buffer)) >= 0) {
                    total += n;
                    if (total > MAX_BYTES) throw new IllegalStateException("adhan file too large");
                    out.write(buffer, 0, n);
                }
                out.getFD().sync();
            }
            if (!isValid(temp)) {
                temp.delete();
                return target;
            }
            if (target.exists() && !target.delete()) return target;
            if (!temp.renameTo(target)) return target;
            return target;
        } catch (Exception e) {
            try { temp.delete(); } catch (Exception ignored) {}
            CrashLogger.recordRuntime(context, "AdhanAudioCache", "تعذر تجهيز ملف الأذان المحلي", e.toString());
            return target;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static boolean isValid(File file) {
        return file != null && file.isFile() && file.length() >= MIN_VALID_BYTES;
    }

    private static String normalizeVoice(String voice) {
        return "qatami".equals(voice) ? "qatami" : "afasy";
    }
}
