package com.mohamedmarey.quran;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class FcmMessageService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "admin_announcements";

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        try { FirebaseMessaging.getInstance().subscribeToTopic(FcmRegistration.TOPIC); }
        catch (Exception e) { CrashLogger.recordRuntime(this, "FCM", "تعذر الاشتراك في قناة الإشعارات", e.toString()); }
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        String title = value(message, "title", "المسلم");
        String body = value(message, "body", "لديك إشعار جديد");
        show(title, body);
    }

    private String value(RemoteMessage message, String key, String fallback) {
        String fromData = message.getData().get(key);
        if (fromData != null && !fromData.trim().isEmpty()) return fromData.trim();
        if (message.getNotification() != null) {
            String v = "title".equals(key) ? message.getNotification().getTitle() : message.getNotification().getBody();
            if (v != null && !v.trim().isEmpty()) return v.trim();
        }
        return fallback;
    }

    private void show(String title, String body) {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;

        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "رسائل المسلم", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("رسائل يرسلها مشرف تطبيق المسلم للمستخدمين");
            nm.createNotificationChannel(channel);
        }

        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 8810, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.app_icon)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setVisibility(Notification.VISIBILITY_PRIVATE);
        nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
