package com.mohamedmarey.quran;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public class AdhanAlarmActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowCompat.enableEdgeToEdge(getWindow());

        String prayer = getIntent() != null ? getIntent().getStringExtra("prayer_name") : null;
        if (prayer == null || prayer.trim().isEmpty()) prayer = "الصلاة";
        LinearLayout content = buildContent(prayer);
        setContentView(content);
        ViewCompat.setOnApplyWindowInsetsListener(content, (view, insets) -> {
            Insets safe = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            view.setPadding(dp(28) + safe.left, dp(36) + safe.top, dp(28) + safe.right, dp(36) + safe.bottom);
            return insets;
        });
    }

    private LinearLayout buildContent(String prayer) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(36), dp(28), dp(36));
        root.setBackgroundColor(Color.rgb(7, 42, 32));

        TextView crescent = new TextView(this);
        crescent.setText("☾");
        crescent.setTextSize(62);
        crescent.setTextColor(Color.rgb(244, 212, 124));
        crescent.setGravity(Gravity.CENTER);
        root.addView(crescent, matchWrap());

        TextView title = new TextView(this);
        title.setText("حان الآن موعد " + prayer);
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = matchWrap();
        tp.topMargin = dp(10);
        root.addView(title, tp);

        TextView subtitle = new TextView(this);
        subtitle.setText("المسلم · جاري تشغيل الأذان");
        subtitle.setTextColor(Color.rgb(212, 232, 223));
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = matchWrap();
        sp.topMargin = dp(8);
        root.addView(subtitle, sp);

        Button stop = new Button(this);
        stop.setText("إيقاف الأذان");
        stop.setTextSize(17);
        stop.setTextColor(Color.rgb(18, 51, 41));
        stop.setBackgroundColor(Color.rgb(244, 212, 124));
        stop.setOnClickListener(v -> {
            Intent service = new Intent(this, AdhanService.class);
            service.setAction(AdhanService.ACTION_STOP);
            startService(service);
            finish();
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        bp.topMargin = dp(34);
        root.addView(stop, bp);

        Button open = new Button(this);
        open.setText("فتح تطبيق المسلم");
        open.setTextSize(16);
        open.setTextColor(Color.WHITE);
        open.setBackgroundColor(Color.rgb(20, 91, 69));
        open.setOnClickListener(v -> {
            Intent main = new Intent(this, MainActivity.class);
            main.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(main);
            finish();
        });
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        op.topMargin = dp(12);
        root.addView(open, op);

        return root;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
