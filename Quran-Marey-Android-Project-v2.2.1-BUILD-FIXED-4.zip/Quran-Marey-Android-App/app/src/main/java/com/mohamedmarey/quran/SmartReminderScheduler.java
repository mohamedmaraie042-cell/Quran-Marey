package com.mohamedmarey.quran;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

import java.util.Calendar;

public final class SmartReminderScheduler {
    private static final String PREFS = "al_muslim_smart_reminders";
    private static final String KEY_JSON = "config_json";
    private SmartReminderScheduler() {}

    public static void configure(Context context, String json) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_JSON, json == null ? "{}" : json).apply();
        try {
            JSONObject j = new JSONObject(json == null ? "{}" : json);
            scheduleDaily(context, "morning", j.optBoolean("morning", true), j.optInt("morningHour", 7), j.optInt("morningMinute", 0));
            scheduleDaily(context, "evening", j.optBoolean("evening", true), j.optInt("eveningHour", 18), j.optInt("eveningMinute", 0));
            scheduleDaily(context, "night", j.optBoolean("night", false), j.optInt("nightHour", 2), j.optInt("nightMinute", 30));
            scheduleFriday(context, j.optBoolean("friday", true), j.optInt("fridayHour", 10), j.optInt("fridayMinute", 0));
        } catch (Exception ignored) {}
    }

    public static void restore(Context context) {
        String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_JSON, null);
        if (json != null) configure(context, json);
    }

    private static void scheduleDaily(Context context, String type, boolean enabled, int hour, int minute) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(context, type);
        if (am == null) return;
        am.cancel(pi);
        if (!enabled) return;
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, Math.max(0, Math.min(23, hour)));
        c.set(Calendar.MINUTE, Math.max(0, Math.min(59, minute)));
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }

    private static void scheduleFriday(Context context, boolean enabled, int hour, int minute) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(context, "friday");
        if (am == null) return;
        am.cancel(pi);
        if (!enabled) return;
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY);
        c.set(Calendar.HOUR_OF_DAY, Math.max(0, Math.min(23, hour)));
        c.set(Calendar.MINUTE, Math.max(0, Math.min(59, minute)));
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.WEEK_OF_YEAR, 1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), 7L * AlarmManager.INTERVAL_DAY, pi);
    }

    private static PendingIntent pending(Context context, String type) {
        Intent i = new Intent(context, SmartReminderReceiver.class);
        i.putExtra("type", type);
        return PendingIntent.getBroadcast(context, 8200 + Math.abs(type.hashCode() % 500), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
