package com.mohamedmarey.quran;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Context app = context.getApplicationContext();
        try { PrayerAlarmScheduler.restore(app); PrayerAlarmScheduler.scheduleRenewalCheck(app); }
        catch (Exception e) { CrashLogger.recordRuntime(app, "BootReceiver", "فشل استعادة منبهات الصلاة", e.toString()); }
        try { PrayerTimesNotificationManager.restore(app); }
        catch (Exception e) { CrashLogger.recordRuntime(app, "BootReceiver", "فشل استعادة إشعار المواقيت", e.toString()); }
        try { SmartReminderScheduler.restore(app); }
        catch (Exception e) { CrashLogger.recordRuntime(app, "BootReceiver", "فشل استعادة التذكيرات", e.toString()); }

        final PendingResult pending = goAsync();
        new Thread(() -> {
            try { AdhanAudioCache.ensureAllCachedBlocking(app); }
            catch (Exception e) { CrashLogger.recordRuntime(app, "AdhanPrefetch", "فشل تجهيز ملفات الأذان المحلية بعد إعادة التشغيل", e.toString()); }
            finally { pending.finish(); }
        }, "BootAdhanPrefetch").start();
    }
}
