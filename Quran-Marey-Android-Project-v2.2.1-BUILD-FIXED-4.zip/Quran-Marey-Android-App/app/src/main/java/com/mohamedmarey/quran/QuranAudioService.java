package com.mohamedmarey.quran;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

public class QuranAudioService extends Service {
    public static final String ACTION_PLAY_URL = "com.mohamedmarey.quran.QURAN_PLAY_URL";
    public static final String ACTION_PAUSE = "com.mohamedmarey.quran.QURAN_PAUSE";
    public static final String ACTION_RESUME = "com.mohamedmarey.quran.QURAN_RESUME";
    public static final String ACTION_STOP = "com.mohamedmarey.quran.QURAN_STOP";
    public static final String ACTION_NEXT = "com.mohamedmarey.quran.QURAN_NEXT";
    public static final String ACTION_PREV = "com.mohamedmarey.quran.QURAN_PREV";

    private static final String CHANNEL = "quran_background_player";
    private static final int ID = 7601;
    private static final String PREFS = "al_muslim_quran_audio";
    private static final String P_URL = "url", P_TITLE = "title", P_SUBTITLE = "subtitle", P_NEXT = "next", P_PREV = "prev", P_POS = "pos", P_ACTIVE = "active";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private MediaSession session;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;

    private String title = "القرآن الكريم";
    private String subtitle = "المسلم";
    private String currentUrl = "";
    private String nextUrl = "";
    private String prevUrl = "";
    private int retryCount = 0;
    private int resumePositionMs = 0;
    private boolean userPaused = false;
    private boolean playWhenPrepared = true;

    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if (change == AudioManager.AUDIOFOCUS_LOSS) {
            pauseInternal(true);
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            if (player != null && player.isPlaying()) {
                try { player.pause(); } catch (Exception ignored) {}
                updateSession(false);
                notifyNow(false);
            }
        } else if (change == AudioManager.AUDIOFOCUS_GAIN && !userPaused) {
            resume();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        session = new MediaSession(this, "AlMuslimQuranSession");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onStop() { stopEverything(); }
            @Override public void onSkipToNext() { if (!nextUrl.isEmpty()) playUrl(nextUrl, "السورة التالية", subtitle, "", "", 0, true); }
            @Override public void onSkipToPrevious() { if (!prevUrl.isEmpty()) playUrl(prevUrl, "السورة السابقة", subtitle, "", "", 0, true); }
            @Override public void onSeekTo(long pos) {
                if (player != null) try {
                    player.seekTo((int)Math.min(Integer.MAX_VALUE, Math.max(0L, pos)));
                    persistState(true);
                } catch (Exception ignored) {}
            }
        });
        session.setActive(true);
        acquireLocks();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            restoreState();
            if (!currentUrl.isEmpty() && prefs().getBoolean(P_ACTIVE, false)) {
                playUrl(currentUrl, title, subtitle, prevUrl, nextUrl, resumePositionMs, !userPaused);
                return START_STICKY;
            }
            stopSelf();
            return START_NOT_STICKY;
        }

        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) { stopEverything(); return START_NOT_STICKY; }
        if (ACTION_PAUSE.equals(action)) { pause(); return START_STICKY; }
        if (ACTION_RESUME.equals(action)) { resume(); return START_STICKY; }
        if (ACTION_NEXT.equals(action)) { if (!nextUrl.isEmpty()) playUrl(nextUrl, "السورة التالية", subtitle, "", "", 0, true); return START_STICKY; }
        if (ACTION_PREV.equals(action)) { if (!prevUrl.isEmpty()) playUrl(prevUrl, "السورة السابقة", subtitle, "", "", 0, true); return START_STICKY; }

        if (ACTION_PLAY_URL.equals(action)) {
            String url = intent.getStringExtra("url");
            title = safe(intent.getStringExtra("title"), "القرآن الكريم");
            subtitle = safe(intent.getStringExtra("subtitle"), "المسلم");
            nextUrl = safe(intent.getStringExtra("next_url"), "");
            prevUrl = safe(intent.getStringExtra("prev_url"), "");
            if (NetworkPolicy.isAllowedQuranAudioUrl(url)) {
                retryCount = 0;
                resumePositionMs = 0;
                userPaused = false;
                playUrl(url, title, subtitle, prevUrl, nextUrl, 0, true);
                return START_STICKY;
            }
            CrashLogger.recordRuntime(this, "QuranAudioService", "رابط صوت غير صالح", String.valueOf(url));
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private void playUrl(String url, String newTitle, String newSubtitle, String prev, String next, int startAtMs, boolean shouldPlay) {
        if (!NetworkPolicy.isAllowedQuranAudioUrl(url)) {
            CrashLogger.recordRuntime(this, "QuranAudioService", "تم رفض مصدر صوت خارج القائمة المسموحة", String.valueOf(url));
            stopEverything(false);
            return;
        }
        currentUrl = safe(url, currentUrl);
        title = safe(newTitle, title);
        subtitle = safe(newSubtitle, subtitle);
        if (prev != null) prevUrl = NetworkPolicy.isAllowedQuranAudioUrl(prev) ? prev : "";
        if (next != null) nextUrl = NetworkPolicy.isAllowedQuranAudioUrl(next) ? next : "";
        if (prevUrl == null || prevUrl.isEmpty()) prevUrl = adjacentUrl(currentUrl, -1);
        if (nextUrl == null || nextUrl.isEmpty()) nextUrl = adjacentUrl(currentUrl, 1);
        resumePositionMs = Math.max(0, startAtMs);
        playWhenPrepared = shouldPlay;
        userPaused = !shouldPlay;
        releasePlayer();
        requestAudioFocus();
        acquireLocks();

        try {
            player = new MediaPlayer();
            player.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(this, Uri.parse(currentUrl));
            player.setOnPreparedListener(mp -> {
                try {
                    if (resumePositionMs > 0 && resumePositionMs < mp.getDuration()) mp.seekTo(resumePositionMs);
                } catch (Exception ignored) {}
                if (playWhenPrepared) {
                    try { mp.start(); } catch (Exception ignored) {}
                }
                retryCount = 0;
                updateSession(playWhenPrepared);
                startForeground(ID, buildNotification(playWhenPrepared));
                persistState(true);
            });
            player.setOnCompletionListener(mp -> {
                resumePositionMs = 0;
                retryCount = 0;
                if (!nextUrl.isEmpty()) playUrl(nextUrl, "السورة التالية", subtitle, "", "", 0, true);
                else stopEverything();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                int pos = safePosition();
                CrashLogger.recordRuntime(this, "QuranAudioService", "انقطاع مشغل القرآن", "what=" + what + ", extra=" + extra + ", retry=" + retryCount + ", url=" + currentUrl);
                releasePlayer();
                if (retryCount < 3 && !currentUrl.isEmpty()) {
                    retryCount++;
                    resumePositionMs = Math.max(0, pos - 1500);
                    handler.postDelayed(() -> playUrl(currentUrl, title, subtitle, prevUrl, nextUrl, resumePositionMs, !userPaused), 1800L * retryCount);
                } else {
                    notifyPlaybackProblem();
                    stopEverything(false);
                }
                return true;
            });
            player.prepareAsync();
            startForeground(ID, buildNotification(false));
            persistState(true);
        } catch (Exception e) {
            CrashLogger.recordRuntime(this, "QuranAudioService", "تعذر تشغيل رابط القرآن", e.toString());
            if (retryCount < 3 && !currentUrl.isEmpty()) {
                retryCount++;
                handler.postDelayed(() -> playUrl(currentUrl, title, subtitle, prevUrl, nextUrl, resumePositionMs, !userPaused), 1800L * retryCount);
            } else {
                notifyPlaybackProblem();
                stopEverything(false);
            }
        }
    }

    private void pause() { pauseInternal(true); }

    private void pauseInternal(boolean markUserPaused) {
        if (markUserPaused) userPaused = true;
        if (player != null) {
            try { if (player.isPlaying()) player.pause(); } catch (Exception ignored) {}
        }
        resumePositionMs = safePosition();
        updateSession(false);
        notifyNow(false);
        persistState(true);
    }

    private void resume() {
        userPaused = false;
        requestAudioFocus();
        acquireLocks();
        if (player != null) {
            try {
                player.start();
                updateSession(true);
                notifyNow(true);
                persistState(true);
                return;
            } catch (Exception ignored) {}
        }
        if (!currentUrl.isEmpty()) playUrl(currentUrl, title, subtitle, prevUrl, nextUrl, resumePositionMs, true);
    }

    private void updateSession(boolean playing) {
        long pos = safePosition();
        long dur = 0;
        try { if (player != null) dur = player.getDuration(); } catch (Exception ignored) {}
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, subtitle)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, dur)
                .build());
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_STOP
                | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, pos, playing ? 1f : 0f)
                .build());
    }

    private Notification buildNotification(boolean playing) {
        Intent open = new Intent(this, MainActivity.class);
        open.putExtra("open_tab", "listen");
        PendingIntent openPi = PendingIntent.getActivity(this, 7601, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent prevPi = servicePi(ACTION_PREV, 7602);
        PendingIntent togglePi = servicePi(playing ? ACTION_PAUSE : ACTION_RESUME, 7603);
        PendingIntent nextPi = servicePi(ACTION_NEXT, 7604);
        PendingIntent stopPi = servicePi(ACTION_STOP, 7605);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.app_icon)
                .setContentTitle(title)
                .setContentText(playing ? subtitle + " · يعمل في الخلفية" : subtitle + " · متوقف مؤقتًا")
                .setContentIntent(openPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous, "السابق", prevPi).build())
                .addAction(new Notification.Action.Builder(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, playing ? "إيقاف مؤقت" : "تشغيل", togglePi).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next, "التالي", nextPi).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPi).build())
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2));
        return b.build();
    }

    private PendingIntent servicePi(String action, int code) {
        Intent i = new Intent(this, QuranAudioService.class);
        i.setAction(action);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private int safePosition() {
        try { return player == null ? resumePositionMs : Math.max(0, player.getCurrentPosition()); }
        catch (Exception e) { return Math.max(0, resumePositionMs); }
    }

    private void requestAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (focusRequest == null) {
                    AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
                    focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(attrs)
                            .setOnAudioFocusChangeListener(focusListener)
                            .setWillPauseWhenDucked(true)
                            .build();
                }
                audioManager.requestAudioFocus(focusRequest);
            } else {
                //noinspection deprecation
                audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            }
        } catch (Exception ignored) {}
    }

    private void abandonAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && focusRequest != null) audioManager.abandonAudioFocusRequest(focusRequest);
            else {
                //noinspection deprecation
                audioManager.abandonAudioFocus(focusListener);
            }
        } catch (Exception ignored) {}
    }

    private void acquireLocks() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) {
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlMuslim:QuranPlayback");
                    wakeLock.setReferenceCounted(false);
                }
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(6 * 60 * 60 * 1000L);
        } catch (Exception ignored) {}
        try {
            if (wifiLock == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    //noinspection deprecation
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "AlMuslim:QuranWifi");
                    wifiLock.setReferenceCounted(false);
                }
            }
            if (wifiLock != null && !wifiLock.isHeld()) wifiLock.acquire();
        } catch (Exception ignored) {}
    }

    private void releaseLocks() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) {}
    }

    private void notifyPlaybackProblem() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
            Intent open = new Intent(this, MainActivity.class); open.putExtra("open_tab", "listen");
            PendingIntent pi = PendingIntent.getActivity(this, 7699, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.setSmallIcon(R.drawable.app_icon).setContentTitle("توقف تشغيل القرآن مؤقتًا")
                    .setContentText("تحقق من الإنترنت واضغط لاستكمال التلاوة")
                    .setContentIntent(pi).setAutoCancel(true).setPriority(Notification.PRIORITY_DEFAULT);
            nm.notify(7699, b.build());
        } catch (Exception ignored) {}
    }

    private void notifyNow(boolean playing) {
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(nm!=null)nm.notify(ID,buildNotification(playing));
    }

    private void createChannel() {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationManager nm=getSystemService(NotificationManager.class);
            if(nm!=null){
                NotificationChannel c=new NotificationChannel(CHANNEL,"مشغل القرآن في الخلفية",NotificationManager.IMPORTANCE_LOW);
                c.setDescription("تشغيل القرآن بشكل مستمر والتحكم من شاشة القفل والسماعات");
                c.setSound(null,null);
                c.enableVibration(false);
                nm.createNotificationChannel(c);
            }
        }
    }

    private void persistState(boolean active) {
        resumePositionMs = safePosition();
        prefs().edit()
                .putString(P_URL, currentUrl)
                .putString(P_TITLE, title)
                .putString(P_SUBTITLE, subtitle)
                .putString(P_NEXT, nextUrl)
                .putString(P_PREV, prevUrl)
                .putInt(P_POS, resumePositionMs)
                .putBoolean(P_ACTIVE, active)
                .apply();
    }

    private void restoreState() {
        SharedPreferences p = prefs();
        currentUrl = p.getString(P_URL, "");
        title = p.getString(P_TITLE, "القرآن الكريم");
        subtitle = p.getString(P_SUBTITLE, "المسلم");
        nextUrl = p.getString(P_NEXT, "");
        prevUrl = p.getString(P_PREV, "");
        resumePositionMs = p.getInt(P_POS, 0);
    }

    private SharedPreferences prefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }

    private void stopEverything() { stopEverything(true); }
    private void stopEverything(boolean clearState) {
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        abandonAudioFocus();
        releaseLocks();
        if(session!=null){ session.setPlaybackState(new PlaybackState.Builder().setState(PlaybackState.STATE_STOPPED,0,0).build()); }
        if (clearState) prefs().edit().clear().apply(); else prefs().edit().putBoolean(P_ACTIVE, false).putInt(P_POS, resumePositionMs).apply();
        stopForeground(true);
        stopSelf();
    }

    private void releasePlayer(){
        if(player!=null){
            resumePositionMs = safePosition();
            try{player.setOnPreparedListener(null); player.setOnCompletionListener(null); player.setOnErrorListener(null);}catch(Exception ignored){}
            try{player.stop();}catch(Exception ignored){}
            try{player.release();}catch(Exception ignored){}
            player=null;
        }
    }

    private static String adjacentUrl(String url, int delta) {
        if (url == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{3})(\\.mp3)(?:\\?.*)?$").matcher(url);
        if (!m.find()) return "";
        try {
            int n = Integer.parseInt(m.group(1)) + delta;
            if (n < 1 || n > 114) return "";
            String rep = String.format(java.util.Locale.US, "%03d.mp3", n);
            return url.substring(0, m.start(1)) + rep;
        } catch (Exception e) { return ""; }
    }

    private static String safe(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}

    @Override public void onTaskRemoved(Intent rootIntent) {
        persistState(true);
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy(){
        persistState(player != null && !currentUrl.isEmpty());
        releasePlayer();
        abandonAudioFocus();
        releaseLocks();
        if(session!=null){session.release();session=null;}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent){return null;}
}
