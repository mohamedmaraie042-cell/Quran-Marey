package com.mohamedmarey.quran;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

public final class PrayerAlarmScheduler {
    private static final String PREFS = "quran_marey_prayers";
    private static final String KEY_JSON = "scheduled_prayers_json";
    private static final String KEY_CODES = "scheduled_prayer_codes";
    private static final String KEY_ENABLED = "adhan_enabled";
    private static final int RENEW_REQUEST_CODE = 7402;
    private static final long RENEW_INTERVAL_MS = 12L * 60L * 60L * 1000L;

    private PrayerAlarmScheduler() {}

    public static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (!enabled) {
            cancelAll(context);
            cancelRenewal(context);
            return;
        }
        renewRollingSchedule(context);
        scheduleRenewalCheck(context);
    }

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, false);
    }

    public static boolean saveCalculationConfig(Context context, String json) {
        boolean saved = PrayerCalculationConfig.save(context, json);
        if (saved && isEnabled(context)) {
            renewRollingSchedule(context);
            scheduleRenewalCheck(context);
        }
        return saved;
    }

    public static int scheduleFromJson(Context context, String json) {
        if (json == null) return 0;
        prefs(context).edit().putString(KEY_JSON, json).apply();
        if (!isEnabled(context)) return 0;

        cancelAll(context);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return 0;

        int scheduled = 0;
        Set<String> codes = new HashSet<>();
        long now = System.currentTimeMillis();

        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String prayer = item.optString("name", "الصلاة");
                long when = item.optLong("time", 0L);
                if (!PrayerScheduleLogic.isFutureEnough(now, when)) continue;

                int code = PrayerScheduleLogic.requestCode(prayer, when);
                PendingIntent pendingIntent = pendingIntent(context, prayer, code, false, 0);
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pendingIntent);
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pendingIntent);
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, when, pendingIntent);
                    }
                    codes.add(String.valueOf(code));
                    scheduled++;
                } catch (SecurityException exactAlarmDenied) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pendingIntent);
                    codes.add(String.valueOf(code));
                    scheduled++;
                }

                int preMinutes = PrayerScheduleLogic.clampPreMinutes(item.optInt("preMinutes", 0));
                long preWhen = when - preMinutes * 60000L;
                if (preMinutes > 0 && preWhen > now + 15000L) {
                    int preCode = PrayerScheduleLogic.requestCode(prayer + "-pre", preWhen);
                    PendingIntent prePi = pendingIntent(context, prayer, preCode, true, preMinutes);
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, preWhen, prePi);
                        } else {
                            alarmManager.set(AlarmManager.RTC_WAKEUP, preWhen, prePi);
                        }
                        codes.add(String.valueOf(preCode));
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception e) {
            CrashLogger.recordRuntime(context, "PrayerScheduler", "جدول الصلاة غير صالح", e.toString());
            return 0;
        }

        prefs(context).edit().putStringSet(KEY_CODES, codes).apply();
        scheduleRenewalCheck(context);
        return scheduled;
    }

    /** Recalculates 30 rolling days natively; no UI/network is required once config was saved. */
    public static int renewRollingSchedule(Context context) {
        if (!isEnabled(context)) return 0;
        PrayerCalculationConfig config = PrayerCalculationConfig.load(context);
        if (config == null || !config.isUsable()) return restoreSavedOnly(context);
        try {
            JSONArray schedule = LocalPrayerCalculator.generateSchedule(System.currentTimeMillis(), 30, config);
            if (schedule.length() == 0) return restoreSavedOnly(context);
            return scheduleFromJson(context, schedule.toString());
        } catch (Exception e) {
            CrashLogger.recordRuntime(context, "PrayerScheduler", "فشل الحساب المحلي المتجدد", e.toString());
            return restoreSavedOnly(context);
        }
    }

    public static void restore(Context context) {
        if (!isEnabled(context)) return;
        int count = renewRollingSchedule(context);
        if (count == 0) restoreSavedOnly(context);
        scheduleRenewalCheck(context);
    }

    private static int restoreSavedOnly(Context context) {
        String json = prefs(context).getString(KEY_JSON, null);
        return json == null ? 0 : scheduleFromJson(context, json);
    }

    public static void scheduleRenewalCheck(Context context) {
        if (!isEnabled(context)) return;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        long when = System.currentTimeMillis() + RENEW_INTERVAL_MS;
        PendingIntent pi = renewalPendingIntent(context, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (Exception ignored) {}
    }

    public static void cancelAll(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Set<String> codes = new HashSet<>(prefs(context).getStringSet(KEY_CODES, new HashSet<>()));
        if (alarmManager != null) {
            for (String raw : codes) {
                try {
                    int code = Integer.parseInt(raw);
                    Intent intent = new Intent(context, PrayerAlarmReceiver.class);
                    PendingIntent pi = PendingIntent.getBroadcast(context, code, intent,
                            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                    if (pi != null) { alarmManager.cancel(pi); pi.cancel(); }
                } catch (Exception ignored) {}
            }
        }
        prefs(context).edit().remove(KEY_CODES).apply();
    }

    private static void cancelRenewal(Context context) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            PendingIntent pi = renewalPendingIntent(context, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (am != null && pi != null) { am.cancel(pi); pi.cancel(); }
        } catch (Exception ignored) {}
    }

    private static PendingIntent renewalPendingIntent(Context context, int flags) {
        Intent intent = new Intent(context, PrayerScheduleRenewReceiver.class);
        return PendingIntent.getBroadcast(context, RENEW_REQUEST_CODE, intent, flags);
    }

    private static PendingIntent pendingIntent(Context context, String prayer, int code, boolean preAlert, int preMinutes) {
        Intent intent = new Intent(context, PrayerAlarmReceiver.class);
        intent.putExtra("prayer_name", prayer);
        intent.putExtra("pre_alert", preAlert);
        intent.putExtra("pre_minutes", preMinutes);
        return PendingIntent.getBroadcast(context, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
