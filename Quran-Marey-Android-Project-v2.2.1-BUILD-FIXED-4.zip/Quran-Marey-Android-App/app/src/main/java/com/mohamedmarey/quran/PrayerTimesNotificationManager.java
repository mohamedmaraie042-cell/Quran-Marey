package com.mohamedmarey.quran;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class PrayerTimesNotificationManager {
    private static final String PREFS = "quran_marey_prayer_times_notification";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_JSON = "today_json";
    private static final int NOTIFICATION_ID = 4106;
    private static final int REFRESH_CODE = 4107;
    private static final String CHANNEL_ID = "prayer_times_persistent_v2";

    private PrayerTimesNotificationManager() {}

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (enabled) restore(context); else cancel(context);
    }

    public static void updateFromJson(Context context, String json) {
        if (json == null || json.trim().isEmpty()) return;
        prefs(context).edit().putString(KEY_JSON, json).apply();
        PrayerWidgetProvider.updateAll(context, json);
        if (!isEnabled(context)) return;
        post(context, json);
    }

    public static void restore(Context context) {
        if (!isEnabled(context)) return;
        String json = prefs(context).getString(KEY_JSON, null);
        if (json != null) {
            PrayerWidgetProvider.updateAll(context, json);
            post(context, json);
        }
    }

    public static void cancel(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            PendingIntent pi = refreshPendingIntent(context, PendingIntent.FLAG_NO_CREATE);
            if (pi != null) { am.cancel(pi); pi.cancel(); }
        }
    }

    private static void post(Context context, String json) {
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;

        try {
            JSONObject root = new JSONObject(json);
            JSONObject day = resolveDay(root);
            JSONObject timings = day.optJSONObject("timings");
            if (timings == null) timings = root.optJSONObject("timings");
            if (timings == null) return;

            String fajr = clean(timings.optString("Fajr", "--:--"));
            String sunrise = clean(timings.optString("Sunrise", "--:--"));
            String dhuhr = clean(timings.optString("Dhuhr", "--:--"));
            String asr = clean(timings.optString("Asr", "--:--"));
            String maghrib = clean(timings.optString("Maghrib", "--:--"));
            String isha = clean(timings.optString("Isha", "--:--"));
            String location = root.optString("location", "").trim();
            String gregorian = day.optString("gregorian", root.optString("date", "")).trim();
            String hijri = day.optString("hijri", "").trim();

            NextPrayer next = calculateNext(root, day);
            createChannel(context);

            Intent open = new Intent(context, MainActivity.class);
            open.putExtra("open_tab", "prayer");
            open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent openPi = PendingIntent.getActivity(context, 4106, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            String title = next == null ? "مواقيت الصلاة اليوم" : "الصلاة القادمة: " + next.name + " · " + next.time;
            String compact = "ف " + fajr + "  ظ " + dhuhr + "  ع " + asr + "  م " + maghrib + "  عـ " + isha;
            String big = "الفجر  " + fajr + "      الشروق  " + sunrise
                    + "\nالظهر   " + dhuhr + "      العصر   " + asr
                    + "\nالمغرب " + maghrib + "      العشاء   " + isha;
            if (next != null) big += "\n⏳ " + next.name + " بعد " + humanRemaining(next.when - System.currentTimeMillis());
            if (!location.isEmpty()) big += "\n📍 " + location;
            if (!gregorian.isEmpty() || !hijri.isEmpty()) big += "\n" + gregorian + (hijri.isEmpty() ? "" : " · " + hijri + " هـ");

            Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new Notification.Builder(context, CHANNEL_ID)
                    : new Notification.Builder(context);

            builder.setSmallIcon(R.drawable.app_icon)
                    .setContentTitle(title)
                    .setContentText(compact)
                    .setStyle(new Notification.BigTextStyle().bigText(big))
                    .setContentIntent(openPi)
                    .setOngoing(true)
                    .setAutoCancel(false)
                    .setOnlyAlertOnce(true)
                    .setCategory(Notification.CATEGORY_REMINDER)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setPriority(Notification.PRIORITY_LOW);
            if (next != null && next.when > System.currentTimeMillis()) {
                builder.setWhen(next.when).setShowWhen(true).setUsesChronometer(true);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) builder.setChronometerCountDown(true);
            } else {
                builder.setShowWhen(false);
            }
            if (!location.isEmpty()) builder.setSubText(location);

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIFICATION_ID, builder.build());

            scheduleRefresh(context, next == null ? nextMidnight() : Math.min(next.when + 70000L, nextMidnight()));
        } catch (Exception e) {
            CrashLogger.recordRuntime(context, "PrayerNotification", "تعذر تحديث إشعار مواقيت الصلاة", e.toString());
        }
    }

    private static JSONObject resolveDay(JSONObject root) {
        JSONArray days = root.optJSONArray("days");
        if (days == null || days.length() == 0) return root;
        String today = new SimpleDateFormat("dd-MM-yyyy", Locale.US).format(new Date());
        for (int i = 0; i < days.length(); i++) {
            JSONObject d = days.optJSONObject(i);
            if (d != null && today.equals(d.optString("gregorian", ""))) return d;
        }
        for (int i = 0; i < days.length(); i++) {
            JSONObject d = days.optJSONObject(i);
            if (d == null) continue;
            long noon = dateAtNoon(d.optString("gregorian", ""));
            if (noon >= startOfToday()) return d;
        }
        JSONObject first = days.optJSONObject(0);
        return first == null ? root : first;
    }

    private static NextPrayer calculateNext(JSONObject root, JSONObject currentDay) {
        JSONArray days = root.optJSONArray("days");
        long now = System.currentTimeMillis();
        if (days != null && days.length() > 0) {
            for (int i = 0; i < days.length(); i++) {
                JSONObject d = days.optJSONObject(i);
                if (d == null) continue;
                NextPrayer n = nextInDay(d, now);
                if (n != null) return n;
            }
        }
        return nextInDay(currentDay, now);
    }

    private static NextPrayer nextInDay(JSONObject day, long now) {
        JSONObject timings = day.optJSONObject("timings");
        if (timings == null) return null;
        String date = day.optString("gregorian", new SimpleDateFormat("dd-MM-yyyy", Locale.US).format(new Date()));
        String[][] names = {{"Fajr","الفجر"},{"Dhuhr","الظهر"},{"Asr","العصر"},{"Maghrib","المغرب"},{"Isha","العشاء"}};
        for (String[] n : names) {
            String t = clean(timings.optString(n[0], ""));
            long when = parseDateTime(date, t);
            if (when > now + 15000L) return new NextPrayer(n[1], t, when);
        }
        return null;
    }

    private static long parseDateTime(String date, String time) {
        try {
            String[] d = date.split("-");
            String[] t = time.split(":");
            Calendar c = Calendar.getInstance();
            c.set(Calendar.YEAR, Integer.parseInt(d[2]));
            c.set(Calendar.MONTH, Integer.parseInt(d[1]) - 1);
            c.set(Calendar.DAY_OF_MONTH, Integer.parseInt(d[0]));
            c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(t[0]));
            c.set(Calendar.MINUTE, Integer.parseInt(t[1]));
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            return c.getTimeInMillis();
        } catch (Exception e) { return 0L; }
    }

    private static long dateAtNoon(String date) { return parseDateTime(date, "12:00"); }
    private static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        return c.getTimeInMillis();
    }
    private static long nextMidnight() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR,1); c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,2); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        return c.getTimeInMillis();
    }

    private static String humanRemaining(long diff) {
        diff = Math.max(0L, diff);
        long mins = diff / 60000L;
        long h = mins / 60L, m = mins % 60L;
        if (h > 0 && m > 0) return h + " س " + m + " د";
        if (h > 0) return h + " ساعة";
        return Math.max(1, m) + " دقيقة";
    }

    private static void scheduleRefresh(Context context, long when) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null || when <= System.currentTimeMillis() + 30000L) return;
            PendingIntent pi = refreshPendingIntent(context, PendingIntent.FLAG_UPDATE_CURRENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (Exception ignored) {}
    }

    private static PendingIntent refreshPendingIntent(Context context, int extraFlag) {
        Intent i = new Intent(context, PrayerNotificationRefreshReceiver.class);
        return PendingIntent.getBroadcast(context, REFRESH_CODE, i, extraFlag | PendingIntent.FLAG_IMMUTABLE);
    }

    private static String clean(String value) {
        if (value == null) return "--:--";
        String v = value.trim();
        int p = v.indexOf(' ');
        if (p > 0) v = v.substring(0, p);
        return v.isEmpty() ? "--:--" : v;
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "مواقيت الصلاة الدائمة", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("مواقيت اليوم والصلاة القادمة بشكل دائم مثل تطبيقات مواقيت الصلاة");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static final class NextPrayer {
        final String name, time; final long when;
        NextPrayer(String name, String time, long when) { this.name=name; this.time=time; this.when=when; }
    }
}
