# WebView JavaScript bridge methods are invoked reflectively from page JavaScript.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Android components are also declared in the manifest; keep explicit service/receiver classes safe.
-keep class com.mohamedmarey.quran.FcmMessageService { *; }
-keep class com.mohamedmarey.quran.QuranAudioService { *; }
-keep class com.mohamedmarey.quran.AdhanService { *; }
