# FCM + لوحة الإدارة المنفصلة — v2.2.0

الهدف: لا يوجد GitHub write token ولا Firebase Service Account داخل تطبيق المستخدم.

1. أنشئ Firebase Project واربط Android package: `com.mohamedmarey.quran`.
2. نزّل `google-services.json` من Firebase Console. للإنتاج عبر GitHub Actions، حوّل الملف Base64 وضعه في Secret باسم `GOOGLE_SERVICES_JSON_BASE64`. الـWorkflow يفكّه مؤقتًا داخل Runner قبل البناء ولا يحتاج رفع الملف إلى Git.
3. شغّل مجلد `admin-panel/` على Backend خاص بك. ضع Firebase Service Account على الخادم فقط عبر `GOOGLE_APPLICATION_CREDENTIALS`، وضع مفتاح إدارة طويل وعشوائي في `ADMIN_PANEL_KEY`.
4. تطبيق Android يشترك في Topic باسم `all_users`، والـBackend يرسل Data Push إلى هذا الـTopic عبر Firebase Admin SDK.
5. لا تضع Service Account JSON أو upload keystore أو Admin key داخل APK أو Repository عام.
6. بعد النشر اختبر رسالة Admin والجهاز: التطبيق مفتوح، بالخلفية، الشاشة مقفولة، وبعد Restart، ومع Battery Saver.
