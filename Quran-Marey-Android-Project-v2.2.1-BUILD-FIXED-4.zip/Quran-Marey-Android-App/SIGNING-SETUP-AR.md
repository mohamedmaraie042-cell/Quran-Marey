# توقيع Release AAB — GitHub Actions Secrets

لا ترفع keystore أو كلمات السر داخل Git أو ZIP عام.

أضف داخل GitHub repository > Settings > Secrets and variables > Actions الأسرار التالية:
- `ALMUSLIM_KEYSTORE_BASE64`: ملف upload keystore بعد تحويله Base64 كسطر واحد.
- `ALMUSLIM_KEYSTORE_PASSWORD`
- `ALMUSLIM_KEY_ALIAS`
- `ALMUSLIM_KEY_PASSWORD`

الـWorkflow يبني Debug APK دائمًا. إذا كانت الأسرار الأربعة موجودة، يفك keystore مؤقتًا داخل Runner ويبني `Al-Muslim-v2.2.0-release.aab` ثم يحذف الملف المؤقت. لا يتم تخزين keystore داخل المشروع.

## Firebase config في CI
لعدم رفع `google-services.json` إلى Git العام، ضع Base64 الكامل للملف في Secret باسم `GOOGLE_SERVICES_JSON_BASE64`. الـWorkflow يفك الملف مؤقتًا داخل Runner فقط.
