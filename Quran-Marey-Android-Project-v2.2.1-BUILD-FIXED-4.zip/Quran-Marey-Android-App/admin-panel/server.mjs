import express from 'express';
import { applicationDefault, initializeApp } from 'firebase-admin/app';
import { getMessaging } from 'firebase-admin/messaging';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ADMIN_KEY = process.env.ADMIN_PANEL_KEY || '';
if (ADMIN_KEY.length < 24) throw new Error('ADMIN_PANEL_KEY must be at least 24 characters');
initializeApp({credential: applicationDefault()});

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use((req,res,next)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Permissions-Policy','geolocation=(), microphone=(), camera=()');
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control','no-store');
  next();
});
app.use(express.json({limit:'32kb'}));

const attempts = new Map();
function limited(req) {
  const now = Date.now();
  const key = req.ip || 'unknown';
  const current = attempts.get(key) || {start:now,count:0};
  if (now-current.start > 60_000) { current.start=now; current.count=0; }
  current.count += 1; attempts.set(key,current);
  return current.count > 30;
}
function keyMatches(candidate='') {
  const a=Buffer.from(String(candidate));
  const b=Buffer.from(ADMIN_KEY);
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}

const dir=path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(dir,'public'),{etag:true,maxAge:'5m'}));

app.post('/api/send', async (req,res)=>{
  if (limited(req)) return res.status(429).json({ok:false,error:'too_many_requests'});
  if (!keyMatches(req.header('x-admin-key'))) return res.status(401).json({ok:false,error:'unauthorized'});
  const title=String(req.body?.title||'').trim().slice(0,80);
  const body=String(req.body?.body||'').trim().slice(0,700);
  if(!title||!body) return res.status(400).json({ok:false,error:'title/body required'});
  const id=await getMessaging().send({topic:'all_users',data:{title,body},android:{priority:'high'}});
  res.json({ok:true,id});
});

app.use((err,req,res,next)=>{
  console.error(err?.message || err);
  res.status(500).json({ok:false,error:'server_error'});
});

app.listen(Number(process.env.PORT||8080),()=>console.log('Al-Muslim admin panel ready'));
