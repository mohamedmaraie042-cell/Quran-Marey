# قائمة إصدار المسلم v2.2.1

## قبل البناء
- تأكد أن `compileSdk` و`targetSdk` = 36 وأن AGP = 8.10.1 وGradle = 8.11.1 وJava = 17.
- ضع `GOOGLE_SERVICES_JSON_BASE64` في GitHub Secrets للإصدار Production.
- ضع أسرار التوقيع الأربعة في GitHub Secrets ولا ترفع ملف keystore إلى Git.
- استبدل `{{DEVELOPER_NAME}}` و`{{PRIVACY_CONTACT}}` في سياسة الخصوصية ثم انشرها على رابط HTTPS عام.

## اختبارات CI المطلوبة
- `scripts/regression-check.mjs`
- `testDebugUnitTest`
- `lintDebug` و`lintRelease`
- `assembleDebug`
- `connectedDebugAndroidTest` على API 36
- `bundleRelease` بتوقيع Production

## اختبارات الجهاز الحقيقي
- موقع تقريبي + اختيار مدينة يدويًا + تغيير طريقة الحساب.
- إغلاق التطبيق وإعادة التشغيل وانتظار الأذان/التذكير بدون فتح الواجهة.
- اختبار الأذان بعد تجهيز الصوت ثم قطع الإنترنت؛ يجب التشغيل من الكاش المحلي.
- اختبار أول تشغيل بدون إنترنت: يظهر تنبيه أن تسجيل الأذان يحتاج تجهيزًا مسبقًا ولا يستخدم TTS/AI.
- تشغيل القرآن في الخلفية مع قفل الشاشة/Bluetooth ثم بدء الأذان وانتهائه.
- Backup/Restore والتأكد من رجوع إعدادات صوت/وضع الأذان ومواقيت الصلاة.
- Samsung/Xiaomi/Oppo مع Battery Optimization، ومع/بدون Exact Alarm وFull-screen Intent.

## شرط النشر
لا تعتبر النسخة Production Ready إلا بعد نجاح CI كاملًا، خروج AAB موقع، وتجربة APK/AAB على جهاز حقيقي.
