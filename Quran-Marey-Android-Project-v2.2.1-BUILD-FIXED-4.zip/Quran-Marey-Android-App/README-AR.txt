المسلم v2.2.0 — Production Hardening
===================================
تطبيق Android إسلامي قيد التطوير، يركز على المصحف بنظام الصفحات، مواقيت الصلاة والإشعار الدائم، الأذان المسجل، والاستماع المستمر للقرآن.

الحد الأدنى: Android 7.0 (API 24)
Compile SDK: 36
Target SDK: 36
AGP: 8.10.1
Gradle: 8.11.1
Java: 17
VersionCode: 13
VersionName: 2.2.0

أهم تغييرات v2.2.0:
- Android 15/16 Edge-to-Edge + WindowInsets + Predictive Back.
- WebView hardening: WebViewAssetLoader، HTTPS/Mixed Content hardening، وإلغاء File/Content/Geolocation access.
- Location تقريبي فقط ACCESS_COARSE_LOCATION.
- Privacy Policy + Data Safety guide + قواعد Backup تمنع رفع البيانات المحلية الحساسة تلقائيًا.
- إزالة GitHub admin token/polling من تطبيق المستخدم؛ إشعارات الإدارة أصبحت FCM مع Backend/لوحة مستقلة.
- CI Production: regression checks + Unit tests + Lint + Debug APK + Signed Release AAB عند تهيئة Secrets.
- Adaptive + Monochrome icon ودعم أفضل للخط الكبير وتقليل الحركة.

قبل النشر:
- أضف app/google-services.json الحقيقي من Firebase إذا أردت Push Notifications.
- انشر docs/privacy-policy.html على HTTPS عام وأضف الرابط في Play Console.
- أضف مفاتيح توقيع Release كـGitHub Actions Secrets فقط، ولا تضع keystore داخل Git.
- نفذ RELEASE-CHECKLIST-v2.2.0-AR.md على أجهزة حقيقية.

راجع CHANGELOG-v2.2.0-AR.txt و PLAY-DATA-SAFETY-AR.md و FCM-ADMIN-SETUP-AR.md.

ملاحظة Gradle Wrapper: ملفات bootstrap وgradle-wrapper.properties موجودة، والـCI ينفذ `gradle wrapper --gradle-version 8.11.1` قبل الاختبارات ليُنشئ الـWrapper الرسمي/JAR داخل الـRunner ثم يستخدم `./gradlew` لباقي المراحل.
