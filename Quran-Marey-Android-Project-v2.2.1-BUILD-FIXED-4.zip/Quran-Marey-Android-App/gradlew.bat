@echo off
setlocal
set APP_HOME=%~dp0
set JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if exist "%JAR%" goto runwrapper
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  echo Gradle wrapper JAR is not materialized yet; using installed Gradle once to bootstrap it.
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle wrapper JAR is missing. Run: gradle wrapper --gradle-version 8.11.1 --distribution-type bin
exit /b 1
:runwrapper
if defined JAVA_HOME (
  "%JAVA_HOME%\bin\java.exe" -Dfile.encoding=UTF-8 -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
) else (
  java -Dfile.encoding=UTF-8 -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
)
