import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const root = path.resolve(process.cwd());
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const fail = msg => { console.error('FAIL:', msg); process.exitCode = 1; };
const ok = msg => console.log('OK:', msg);
const must = (cond, msg) => cond ? ok(msg) : fail(msg);

function extractJsonArrayAfter(source, marker) {
  const startMarker = source.indexOf(marker);
  if (startMarker < 0) throw new Error(`Marker missing: ${marker}`);
  const start = source.indexOf('[', startMarker + marker.length);
  if (start < 0) throw new Error('Array start missing');
  let depth = 0, str = false, esc = false;
  for (let i = start; i < source.length; i++) {
    const c = source[i];
    if (str) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === '"') str = false;
      continue;
    }
    if (c === '"') str = true;
    else if (c === '[') depth++;
    else if (c === ']') {
      depth--;
      if (depth === 0) return JSON.parse(source.slice(start, i + 1));
    }
  }
  throw new Error('Unclosed embedded Quran array');
}

const html = read('app/src/main/assets/index.html');
const manifest = read('app/src/main/AndroidManifest.xml');
const appGradle = read('app/build.gradle');
const rootGradle = read('build.gradle');
const mainActivity = read('app/src/main/java/com/mohamedmarey/quran/MainActivity.java');
const boot = read('app/src/main/java/com/mohamedmarey/quran/BootReceiver.java');
const audio = read('app/src/main/java/com/mohamedmarey/quran/QuranAudioService.java');
const adhan = read('app/src/main/java/com/mohamedmarey/quran/AdhanService.java');
const adhanCache = read('app/src/main/java/com/mohamedmarey/quran/AdhanAudioCache.java');
const prayerConfig = read('app/src/main/java/com/mohamedmarey/quran/PrayerCalculationConfig.java');
const localPrayer = read('app/src/main/java/com/mohamedmarey/quran/LocalPrayerCalculator.java');
const prayerScheduler = read('app/src/main/java/com/mohamedmarey/quran/PrayerAlarmScheduler.java');
const backupBridge = read('app/src/main/java/com/mohamedmarey/quran/AppSettingsBackup.java');
const workflow = read('.github/workflows/build-apk.yml');
const adhanPrefs = read('app/src/main/java/com/mohamedmarey/quran/AdhanPreferences.java');
const backup = read('app/src/main/res/xml/backup_rules.xml');
const extraction = read('app/src/main/res/xml/data_extraction_rules.xml');
const adminServer = read('admin-panel/server.mjs');

must(/compileSdk\s+36/.test(appGradle), 'compileSdk 36');
must(/targetSdk\s+36/.test(appGradle), 'targetSdk 36');
must(/versionName\s+"2\.2\.1"/.test(appGradle), 'version 2.2.1');
must(/8\.10\.1/.test(rootGradle), 'AGP 8.10.1');
must(!manifest.includes('ACCESS_FINE_LOCATION') && manifest.includes('ACCESS_COARSE_LOCATION'), 'coarse-only location permission');
must(mainActivity.includes('WebViewAssetLoader') && mainActivity.includes('MIXED_CONTENT_NEVER_ALLOW'), 'WebViewAssetLoader + no mixed content');
must(mainActivity.includes('setAllowFileAccess(false)') && mainActivity.includes('setAllowContentAccess(false)'), 'WebView file/content access disabled');
must(mainActivity.includes('setGeolocationEnabled(false)'), 'WebView geolocation disabled');
must(mainActivity.includes('registerOnBackInvokedCallback') && mainActivity.includes('window.handleAndroidBack'), 'predictive back native bridge');
must(mainActivity.includes('WindowCompat.enableEdgeToEdge') && mainActivity.includes('WindowInsetsCompat.Type.systemBars'), 'edge-to-edge insets');
must(boot.includes('PrayerAlarmScheduler.restore') && boot.includes('PrayerTimesNotificationManager.restore') && boot.includes('SmartReminderScheduler.restore'), 'boot restore contracts');
must(!boot.includes('AdminAnnouncement'), 'legacy polling admin scheduler removed');
must(audio.includes('START_STICKY') && audio.includes('MediaSession') && audio.includes('AudioFocusRequest') && audio.includes('NetworkPolicy.isAllowedQuranAudioUrl'), 'background Quran playback resilience and allow-list');
must(!/TextToSpeech|android\.speech\.tts|\bspeak\s*\(/i.test(adhan), 'adhan service contains no TTS/AI playback path');
must(/afasy/.test(adhanPrefs) && /qatami/.test(adhanPrefs), 'adhan preferences include only requested recorded voices');
must(!/["'](?:beautiful|classic|tts|ai)["']/i.test(adhanPrefs), 'legacy/AI adhan voice IDs removed');
must(adhanCache.includes('TvQuran.com__04.athan.mp3') && adhanCache.includes('TvQuran.com__08.athan.mp3') && adhan.includes('AdhanAudioCache.cachedFile'), 'adhan uses only the two recorded Mishary/Nasser sources and plays from local cache');
must(adhan.includes('requestTransientAudioFocus()') && adhan.includes('AUDIOFOCUS_GAIN_TRANSIENT'), 'adhan requests transient audio focus so Quran playback can pause/resume cleanly');

must(prayerConfig.includes('if (!o.has(key) || o.isNull(key)) return null') && prayerConfig.includes('String s = String.valueOf(raw).trim()'), 'missing prayer coordinates are rejected instead of coercing to 0,0');
must(localPrayer.includes('case 1: return new MethodAngles(18d, 18d, 0)') && localPrayer.includes('case 4: return new MethodAngles(18.5d, 0d, 90)') && localPrayer.includes('19.5d, 17.5d'), 'offline/native prayer calculator respects selected calculation method');
must(localPrayer.includes('TimeZone.getTimeZone(c.timezone)') && localPrayer.includes('zone.getOffset'), 'native prayer schedule uses selected location timezone/DST');
must(prayerScheduler.includes('generateSchedule(System.currentTimeMillis(), 30, config)') && prayerScheduler.includes('PrayerScheduleRenewReceiver') && prayerScheduler.includes('RENEW_INTERVAL_MS'), 'adhan schedule renews natively beyond the UI 14-day cache');
must(adhanCache.includes('adhan-cache') && adhanCache.includes('ensureAllCachedAsync') && adhanCache.includes('NetworkPolicy.isAllowedAdhanUrl'), 'recorded adhan is prefetched into app-private local cache with host validation');
must(backupBridge.includes('quran_marey_adhan_prefs') && backupBridge.includes('PrayerCalculationConfig.exportRaw') && backupBridge.includes('PrayerAlarmScheduler.restore'), 'manual backup includes native adhan/prayer settings and re-schedules after restore');
must(html.includes('exportNativePreferences') && html.includes('importNativePreferences'), 'web backup is bridged to native SharedPreferences');
must(workflow.includes('connectedDebugAndroidTest') && workflow.includes('api-level: 36'), 'CI runs Android 16 instrumentation smoke tests');
must(workflow.includes("settings.gradle.kts") && workflow.includes('gradle-wrapper.jar'), 'CI supports Groovy/Kotlin settings and repairs incomplete wrapper');
must(backup.includes('<exclude domain="sharedpref" path="."/>') && extraction.includes('<exclude domain="sharedpref" path="."/>'), 'sensitive local preferences excluded from system backup/transfer');
must(fs.existsSync(path.join(root,'app/src/main/assets/privacy-policy.html')) && fs.existsSync(path.join(root,'docs/privacy-policy.html')), 'privacy policy packaged in app and docs');
must(fs.existsSync(path.join(root,'app/src/main/java/com/mohamedmarey/quran/FcmMessageService.java')), 'FCM client service present');
must(adminServer.includes('process.env.ADMIN_PANEL_KEY') && adminServer.includes('applicationDefault()'), 'admin backend keeps credentials server-side');
must(!/renderAdminHub|sendAdminAnnouncement|github_pat_|ghp_|x-github-token/i.test(html), 'no GitHub write-token admin UI in user app');

try {
  const quran = extractJsonArrayAfter(html, 'const EMBEDDED_QURAN=');
  const ayahs = quran.flatMap(s => s.ayahs || []);
  const numbers = ayahs.map(a => a.number);
  const pages = new Set(ayahs.map(a => a.page));
  must(quran.length === 114, 'embedded Quran has 114 surahs');
  must(ayahs.length === 6236, 'embedded Quran has 6236 ayahs');
  must(numbers.every((n,i) => n === i + 1), 'embedded Quran global ayah sequence has no gaps');
  must(Math.min(...pages) === 1 && Math.max(...pages) === 604 && pages.size === 604, 'embedded Quran covers all 604 mushaf pages');
} catch (e) { fail(`embedded Quran parse: ${e.message}`); }

must(/localStorage\.setItem/.test(html) && /استيراد|import/i.test(html), 'manual local backup/restore UI contract present');
must(manifest.includes('@xml/backup_rules') && manifest.includes('@xml/data_extraction_rules'), 'backup/data extraction rules wired in manifest');

if (process.exitCode) process.exit(process.exitCode);
console.log('\nProduction regression checks passed.');
