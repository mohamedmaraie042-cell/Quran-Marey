package com.mohamedmarey.quran;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

public class QuranAudioService extends Service {
    public static final String ACTION_PLAY_URL = "com.mohamedmarey.quran.QURAN_PLAY_URL";
    public static final String ACTION_PAUSE = "com.mohamedmarey.quran.QURAN_PAUSE";
    public static final String ACTION_RESUME = "com.mohamedmarey.quran.QURAN_RESUME";
    public static final String ACTION_STOP = "com.mohamedmarey.quran.QURAN_STOP";
    public static final String ACTION_NEXT = "com.mohamedmarey.quran.QURAN_NEXT";
    public static final String ACTION_PREV = "com.mohamedmarey.quran.QURAN_PREV";
    private static final String CHANNEL = "quran_background_player";
    private static final int ID = 7601;

    private MediaPlayer player;
    private MediaSession session;
    private String title = "القرآن الكريم";
    private String subtitle = "المسلم";
    private String currentUrl = "";
    private String nextUrl = "";
    private String prevUrl = "";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        session = new MediaSession(this, "AlMuslimQuranSession");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onStop() { stopEverything(); }
            @Override public void onSkipToNext() { if (!nextUrl.isEmpty()) playUrl(nextUrl, "السورة التالية", subtitle, "", ""); }
            @Override public void onSkipToPrevious() { if (!prevUrl.isEmpty()) playUrl(prevUrl, "السورة السابقة", subtitle, "", ""); }
            @Override public void onSeekTo(long pos) { if (player != null) try { player.seekTo((int)Math.min(Integer.MAX_VALUE, pos)); } catch (Exception ignored) {} }
        });
        session.setActive(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopEverything(); return START_NOT_STICKY; }
        if (ACTION_PAUSE.equals(action)) { pause(); return START_STICKY; }
        if (ACTION_RESUME.equals(action)) { resume(); return START_STICKY; }
        if (ACTION_NEXT.equals(action)) { if (!nextUrl.isEmpty()) playUrl(nextUrl, "السورة التالية", subtitle, "", ""); return START_STICKY; }
        if (ACTION_PREV.equals(action)) { if (!prevUrl.isEmpty()) playUrl(prevUrl, "السورة السابقة", subtitle, "", ""); return START_STICKY; }
        if (ACTION_PLAY_URL.equals(action)) {
            String url = intent.getStringExtra("url");
            title = safe(intent.getStringExtra("title"), "القرآن الكريم");
            subtitle = safe(intent.getStringExtra("subtitle"), "المسلم");
            nextUrl = safe(intent.getStringExtra("next_url"), "");
            prevUrl = safe(intent.getStringExtra("prev_url"), "");
            if (url != null && url.startsWith("https://")) playUrl(url, title, subtitle, prevUrl, nextUrl);
        }
        return START_STICKY;
    }

    private void playUrl(String url, String newTitle, String newSubtitle, String prev, String next) {
        currentUrl = url;
        title = safe(newTitle, title);
        subtitle = safe(newSubtitle, subtitle);
        if (prev != null) prevUrl = prev;
        if (next != null) nextUrl = next;
        if (prevUrl == null || prevUrl.isEmpty()) prevUrl = adjacentUrl(url, -1);
        if (nextUrl == null || nextUrl.isEmpty()) nextUrl = adjacentUrl(url, 1);
        releasePlayer();
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(this, Uri.parse(url));
            player.setOnPreparedListener(mp -> {
                mp.start();
                updateSession(true);
                startForeground(ID, buildNotification(true));
            });
            player.setOnCompletionListener(mp -> {
                if (!nextUrl.isEmpty()) playUrl(nextUrl, "السورة التالية", subtitle, "", "");
                else stopEverything();
            });
            player.setOnErrorListener((mp, what, extra) -> { stopEverything(); return true; });
            player.prepareAsync();
            startForeground(ID, buildNotification(false));
        } catch (Exception e) { stopEverything(); }
    }

    private void pause() {
        if (player != null && player.isPlaying()) {
            try { player.pause(); } catch (Exception ignored) {}
            updateSession(false); notifyNow(false);
        }
    }
    private void resume() {
        if (player != null) {
            try { player.start(); updateSession(true); notifyNow(true); } catch (Exception ignored) {}
        } else if (!currentUrl.isEmpty()) playUrl(currentUrl, title, subtitle, prevUrl, nextUrl);
    }

    private void updateSession(boolean playing) {
        long pos = 0, dur = 0;
        try { if (player != null) { pos = player.getCurrentPosition(); dur = player.getDuration(); } } catch (Exception ignored) {}
        session.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title).putString(MediaMetadata.METADATA_KEY_ARTIST, subtitle).putLong(MediaMetadata.METADATA_KEY_DURATION, dur).build());
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_STOP | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        session.setPlaybackState(new PlaybackState.Builder().setActions(actions).setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, pos, playing ? 1f : 0f).build());
    }

    private Notification buildNotification(boolean playing) {
        Intent open = new Intent(this, MainActivity.class); open.putExtra("open_tab", "listen");
        PendingIntent openPi = PendingIntent.getActivity(this, 7601, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent prevPi = servicePi(ACTION_PREV, 7602), togglePi = servicePi(playing ? ACTION_PAUSE : ACTION_RESUME, 7603), nextPi = servicePi(ACTION_NEXT, 7604), stopPi = servicePi(ACTION_STOP, 7605);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.app_icon).setContentTitle(title).setContentText(subtitle).setContentIntent(openPi).setOngoing(playing).setVisibility(Notification.VISIBILITY_PUBLIC).setCategory(Notification.CATEGORY_TRANSPORT)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous, "السابق", prevPi).build())
                .addAction(new Notification.Action.Builder(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, playing ? "إيقاف مؤقت" : "تشغيل", togglePi).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next, "التالي", nextPi).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPi).build())
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2));
        return b.build();
    }

    private PendingIntent servicePi(String action, int code) {
        Intent i = new Intent(this, QuranAudioService.class); i.setAction(action);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private void notifyNow(boolean playing) { NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(nm!=null)nm.notify(ID,buildNotification(playing)); }
    private void createChannel() { if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){ NotificationManager nm=getSystemService(NotificationManager.class); if(nm!=null){ NotificationChannel c=new NotificationChannel(CHANNEL,"مشغل القرآن في الخلفية",NotificationManager.IMPORTANCE_LOW); c.setDescription("تشغيل القرآن والتحكم من شاشة القفل والسماعات"); nm.createNotificationChannel(c); } } }
    private void stopEverything() { releasePlayer(); if(session!=null){ session.setPlaybackState(new PlaybackState.Builder().setState(PlaybackState.STATE_STOPPED,0,0).build()); } stopForeground(true); stopSelf(); }
    private void releasePlayer(){ if(player!=null){ try{player.stop();}catch(Exception ignored){} try{player.release();}catch(Exception ignored){} player=null; } }
    private static String adjacentUrl(String url, int delta) {
        if (url == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{3})(\\.mp3)(?:\\?.*)?$").matcher(url);
        if (!m.find()) return "";
        try {
            int n = Integer.parseInt(m.group(1)) + delta;
            if (n < 1 || n > 114) return "";
            String rep = String.format(java.util.Locale.US, "%03d.mp3", n);
            return url.substring(0, m.start(1)) + rep;
        } catch (Exception e) { return ""; }
    }

    private static String safe(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}
    @Override public void onDestroy(){ releasePlayer(); if(session!=null){session.release();session=null;} super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){return null;}
}
