package com.mohamedmarey.quran;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class PrayerTimesNotificationManager {
    private static final String PREFS = "quran_marey_prayer_times_notification";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_JSON = "today_json";
    private static final int NOTIFICATION_ID = 4106;
    private static final String CHANNEL_ID = "prayer_times_persistent";

    private PrayerTimesNotificationManager() {}

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (enabled) restore(context); else cancel(context);
    }

    public static void updateFromJson(Context context, String json) {
        if (json == null || json.trim().isEmpty()) return;
        prefs(context).edit().putString(KEY_JSON, json).apply();
        PrayerWidgetProvider.updateAll(context, json);
        if (!isEnabled(context)) return;
        post(context, json);
    }

    public static void restore(Context context) {
        if (!isEnabled(context)) return;
        String json = prefs(context).getString(KEY_JSON, null);
        if (json != null) { PrayerWidgetProvider.updateAll(context, json); post(context, json); }
    }

    public static void cancel(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
    }

    private static void post(Context context, String json) {
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        try {
            JSONObject root = new JSONObject(json);
            JSONObject timings = root.optJSONObject("timings");
            if (timings == null) return;

            String fajr = clean(timings.optString("Fajr", "--:--"));
            String sunrise = clean(timings.optString("Sunrise", "--:--"));
            String dhuhr = clean(timings.optString("Dhuhr", "--:--"));
            String asr = clean(timings.optString("Asr", "--:--"));
            String maghrib = clean(timings.optString("Maghrib", "--:--"));
            String isha = clean(timings.optString("Isha", "--:--"));
            String location = root.optString("location", "").trim();
            String date = root.optString("date", "").trim();
            String nextName = root.optString("nextName", "").trim();
            String nextTime = root.optString("nextTime", "").trim();

            createChannel(context);

            Intent open = new Intent(context, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent openPi = PendingIntent.getActivity(
                    context, 4106, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            String title = nextName.isEmpty() ? "مواقيت الصلاة اليوم" : "الصلاة القادمة: " + nextName + (nextTime.isEmpty() ? "" : " · " + nextTime);
            String compact = "الفجر " + fajr + " · الظهر " + dhuhr + " · العصر " + asr + " · المغرب " + maghrib + " · العشاء " + isha;
            String big = "الفجر: " + fajr + "     الشروق: " + sunrise
                    + "\nالظهر: " + dhuhr + "     العصر: " + asr
                    + "\nالمغرب: " + maghrib + "     العشاء: " + isha;
            if (!location.isEmpty()) big += "\n📍 " + location;
            if (!date.isEmpty()) big += "\n" + date;

            Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new Notification.Builder(context, CHANNEL_ID)
                    : new Notification.Builder(context);

            builder.setSmallIcon(R.drawable.app_icon)
                    .setContentTitle(title)
                    .setContentText(compact)
                    .setStyle(new Notification.BigTextStyle().bigText(big))
                    .setContentIntent(openPi)
                    .setOngoing(true)
                    .setAutoCancel(false)
                    .setOnlyAlertOnce(true)
                    .setShowWhen(false)
                    .setCategory(Notification.CATEGORY_REMINDER)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setPriority(Notification.PRIORITY_LOW);

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIFICATION_ID, builder.build());
        } catch (Exception ignored) {}
    }

    private static String clean(String value) {
        if (value == null) return "--:--";
        String v = value.trim();
        int p = v.indexOf(' ');
        if (p > 0) v = v.substring(0, p);
        return v.isEmpty() ? "--:--" : v;
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "مواقيت الصلاة الدائمة",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("عرض مواقيت الصلاة طوال اليوم في شريط الإشعارات");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
