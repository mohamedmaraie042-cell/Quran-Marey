package com.mohamedmarey.quran;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.Locale;

public class AdhanService extends Service implements TextToSpeech.OnInitListener {
    public static final String ACTION_PLAY = "com.mohamedmarey.quran.PLAY_ADHAN";
    public static final String ACTION_STOP = "com.mohamedmarey.quran.STOP_ADHAN";
    private static final String CHANNEL_ID = "muslim_adhan_v2";
    private static final int NOTIFICATION_ID = 7411;

    // Adhan sources: AlAdhan (Mishary Alafasy), TVQuran (Nasser Al-Qatami), plus fallback recordings.
    private static final String URL_AFASY_1 = "https://cdn.aladhan.com/audio/adhans/a9.mp3";
    private static final String URL_AFASY_2 = "https://cdn.aladhan.com/audio/adhans/a4.mp3";
    private static final String URL_AFASY_3 = "https://cdn.aladhan.com/audio/adhans/a7.mp3";
    private static final String URL_QATAMI = "https://download.tvquran.com/download/TvQuran.com__Athan/TvQuran.com__08.athan.mp3";
    private static final String URL_BEAUTIFUL = "https://upload.wikimedia.org/wikipedia/commons/b/b0/Beautiful_adhan.ogg";
    private static final String URL_CLASSIC = "https://upload.wikimedia.org/wikipedia/commons/e/e7/Adhan.ogg";
    private static final String URL_FULL = "https://upload.wikimedia.org/wikipedia/commons/a/a9/Muslim_calling_to_prayer.ogg";

    private TextToSpeech tts;
    private MediaPlayer player;
    private String prayerName = "الصلاة";
    private boolean fallbackStarted = false;
    private String activeVoice = "afasy";
    private String[] activeUrls = new String[0];
    private int activeUrlIndex = 0;
    private String activeMode = "full";
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAdhan();
            return START_NOT_STICKY;
        }

        prayerName = intent != null ? intent.getStringExtra("prayer_name") : "الصلاة";
        if (prayerName == null || prayerName.trim().isEmpty()) prayerName = "الصلاة";
        startForeground(NOTIFICATION_ID, buildNotification(prayerName));
        activeMode = AdhanPreferences.getPrayerMode(this, prayerName);
        if ("silent".equals(activeMode)) {
            handler.postDelayed(this::stopAdhan, 30000L);
        } else {
            playRecordedAdhan();
        }
        return START_NOT_STICKY;
    }

    private void playRecordedAdhan() {
        fallbackStarted = false;
        releasePlayer();
        shutdownTts();

        activeVoice = AdhanPreferences.getPrayerVoice(this, prayerName);
        activeUrls = selectedAdhanUrls(activeVoice);
        activeUrlIndex = 0;
        if ("tts".equals(activeVoice)) {
            startTtsFallback();
            return;
        }

        int bundled = bundledAdhanResource(activeVoice);
        if (bundled != 0) {
            playSource(Uri.parse("android.resource://" + getPackageName() + "/" + bundled), false);
        } else {
            playNextRemoteSource();
        }
    }

    private void playNextRemoteSource() {
        if (activeUrls == null || activeUrlIndex >= activeUrls.length) {
            startTtsFallback();
            return;
        }
        String url = activeUrls[activeUrlIndex++];
        playSource(Uri.parse(url), true);
    }

    private void playSource(Uri source, boolean remote) {
        releasePlayer();
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(this, source);
            player.setOnPreparedListener(mp -> {
                mp.start();
                if ("short".equals(activeMode)) handler.postDelayed(this::stopAdhan, 20000L);
            });
            player.setOnCompletionListener(mp -> stopAdhan());
            player.setOnErrorListener((mp, what, extra) -> {
                releasePlayer();
                if (remote) playNextRemoteSource();
                else startTtsFallback();
                return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            if (remote) playNextRemoteSource();
            else startTtsFallback();
        }
    }

    private int bundledAdhanResource(String voice) {
        String name;
        if ("classic".equals(voice)) name = "adhan_classic";
        else if ("full".equals(voice)) name = "adhan_full";
        else if ("beautiful".equals(voice)) name = "adhan_beautiful";
        else return 0;
        return getResources().getIdentifier(name, "raw", getPackageName());
    }

    private String[] selectedAdhanUrls(String voice) {
        if ("afasy".equals(voice)) return new String[]{URL_AFASY_1, URL_AFASY_2, URL_AFASY_3};
        if ("qatami".equals(voice)) return new String[]{URL_QATAMI};
        if ("classic".equals(voice)) return new String[]{URL_CLASSIC};
        if ("full".equals(voice)) return new String[]{URL_FULL};
        if ("beautiful".equals(voice)) return new String[]{URL_BEAUTIFUL};
        return new String[0];
    }

    private void startTtsFallback() {
        if (fallbackStarted) return;
        fallbackStarted = true;
        releasePlayer();
        tts = new TextToSpeech(this, this);
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || tts == null) {
            stopAdhan();
            return;
        }

        int language = tts.setLanguage(new Locale("ar", "SA"));
        if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
            stopAdhan();
            return;
        }

        tts.setSpeechRate(0.72f);
        tts.setPitch(0.88f);
        tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build());
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {}
            @Override public void onDone(String utteranceId) { stopAdhan(); }
            @Override public void onError(String utteranceId) { stopAdhan(); }
        });
        String spoken = "short".equals(activeMode) ? ("حان الآن موعد " + prayerName) : buildAdhanText(prayerName);
        tts.speak(spoken, TextToSpeech.QUEUE_FLUSH, null,
                "muslim-adhan-" + System.currentTimeMillis());
    }

    private String buildAdhanText(String prayer) {
        StringBuilder s = new StringBuilder();
        s.append("الله أكبر. الله أكبر. الله أكبر. الله أكبر. ");
        s.append("أشهد أن لا إله إلا الله. أشهد أن لا إله إلا الله. ");
        s.append("أشهد أن محمدًا رسول الله. أشهد أن محمدًا رسول الله. ");
        s.append("حي على الصلاة. حي على الصلاة. ");
        s.append("حي على الفلاح. حي على الفلاح. ");
        if (prayer != null && prayer.contains("الفجر")) {
            s.append("الصلاة خير من النوم. الصلاة خير من النوم. ");
        }
        s.append("الله أكبر. الله أكبر. لا إله إلا الله.");
        return s.toString();
    }

    private Notification buildNotification(String prayer) {
        Intent fullScreen = new Intent(this, AdhanAlarmActivity.class);
        fullScreen.putExtra("prayer_name", prayer);
        fullScreen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fullScreenPi = PendingIntent.getActivity(this, 100, fullScreen,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 102, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, AdhanService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 101, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent adhkar = new Intent(this, MainActivity.class);
        adhkar.putExtra("open_tab", "adhkar_afterPrayer");
        adhkar.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent adhkarPi = PendingIntent.getActivity(this, 103, adhkar,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setSmallIcon(R.drawable.app_icon)
                .setContentTitle("حان الآن موعد " + prayer)
                .setContentText("المسلم · جاري تشغيل الأذان")
                .setContentIntent(openPi)
                .setFullScreenIntent(fullScreenPi, true)
                .setOngoing(true)
                .setAutoCancel(false)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_MAX)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_media_pause, "إيقاف الأذان", stopPi).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_view, "فتح المسلم", openPi).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_agenda, "أذكار بعد الصلاة", adhkarPi).build());
        return builder.build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "الأذان ومواقيت الصلاة",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("تنبيه كامل وقت الصلاة وتشغيل الأذان");
            channel.setSound(null, null);
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void stopAdhan() {
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        shutdownTts();
        stopForeground(true);
        stopSelf();
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    private void shutdownTts() {
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
            try { tts.shutdown(); } catch (Exception ignored) {}
            tts = null;
        }
    }

    @Override
    public void onDestroy() {
        releasePlayer();
        shutdownTts();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
