package com.mohamedmarey.quran;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class PrayerAlarmReceiver extends BroadcastReceiver {
    private static final String PRE_CHANNEL = "prayer_pre_alerts";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!PrayerAlarmScheduler.isEnabled(context)) return;
        String prayer = intent != null ? intent.getStringExtra("prayer_name") : null;
        if (prayer == null) prayer = "الصلاة";
        boolean pre = intent != null && intent.getBooleanExtra("pre_alert", false);
        int minutes = intent == null ? 0 : intent.getIntExtra("pre_minutes", 0);
        if (pre) {
            showPreAlert(context, prayer, minutes);
            return;
        }
        Intent service = new Intent(context, AdhanService.class);
        service.setAction(AdhanService.ACTION_PLAY);
        service.putExtra("prayer_name", prayer);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service);
        else context.startService(service);
    }

    private void showPreAlert(Context context, String prayer, int minutes) {
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(PRE_CHANNEL, "تنبيه قبل الصلاة", NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("تنبيه اختياري قبل وقت الصلاة");
            nm.createNotificationChannel(c);
        }
        Intent open = new Intent(context, MainActivity.class);
        open.putExtra("open_tab", "prayer");
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 7440 + Math.abs(prayer.hashCode() % 200), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, PRE_CHANNEL) : new Notification.Builder(context);
        b.setSmallIcon(R.drawable.app_icon)
                .setContentTitle("متبقي " + minutes + " دقيقة على " + prayer)
                .setContentText("المسلم · استعد للصلاة")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setPriority(Notification.PRIORITY_DEFAULT);
        nm.notify(7440 + Math.abs(prayer.hashCode() % 200), b.build());
    }
}
