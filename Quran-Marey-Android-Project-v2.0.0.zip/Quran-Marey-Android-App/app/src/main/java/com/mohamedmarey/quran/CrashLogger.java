package com.mohamedmarey.quran;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class CrashLogger {
    private static final String PREFS = "al_muslim_diagnostics";
    private static final String KEY = "last_crash";
    private static Thread.UncaughtExceptionHandler previous;

    private CrashLogger() {}

    public static void install(Context context) {
        if (previous != null) return;
        previous = Thread.getDefaultUncaughtExceptionHandler();
        Context app = context.getApplicationContext();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                StringWriter sw = new StringWriter();
                error.printStackTrace(new PrintWriter(sw));
                String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
                String text = stamp + "\n" + error.getClass().getName() + ": " + error.getMessage() + "\n" + sw;
                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, text).apply();
            } catch (Exception ignored) {}
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    public static String get(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "");
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
