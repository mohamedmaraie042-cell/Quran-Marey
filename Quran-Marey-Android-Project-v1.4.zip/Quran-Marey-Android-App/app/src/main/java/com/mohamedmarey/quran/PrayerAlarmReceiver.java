package com.mohamedmarey.quran;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class PrayerAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!PrayerAlarmScheduler.isEnabled(context)) return;
        String prayer = intent != null ? intent.getStringExtra("prayer_name") : null;
        Intent service = new Intent(context, AdhanService.class);
        service.setAction(AdhanService.ACTION_PLAY);
        service.putExtra("prayer_name", prayer == null ? "الصلاة" : prayer);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(service);
        } else {
            context.startService(service);
        }
    }
}
