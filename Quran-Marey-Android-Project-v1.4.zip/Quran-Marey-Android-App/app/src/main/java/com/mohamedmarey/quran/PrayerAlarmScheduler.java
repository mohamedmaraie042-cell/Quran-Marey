package com.mohamedmarey.quran;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

public final class PrayerAlarmScheduler {
    private static final String PREFS = "quran_marey_prayers";
    private static final String KEY_JSON = "scheduled_prayers_json";
    private static final String KEY_CODES = "scheduled_prayer_codes";
    private static final String KEY_ENABLED = "adhan_enabled";

    private PrayerAlarmScheduler() {}

    public static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (!enabled) cancelAll(context);
    }

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, false);
    }

    public static int scheduleFromJson(Context context, String json) {
        if (json == null) return 0;
        prefs(context).edit().putString(KEY_JSON, json).apply();
        if (!isEnabled(context)) return 0;

        cancelAll(context);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return 0;

        int scheduled = 0;
        Set<String> codes = new HashSet<>();
        long now = System.currentTimeMillis();

        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String prayer = item.optString("name", "الصلاة");
                long when = item.optLong("time", 0L);
                if (when <= now + 15000L) continue;

                int code = requestCode(prayer, when);
                PendingIntent pendingIntent = pendingIntent(context, prayer, code);
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pendingIntent);
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pendingIntent);
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, when, pendingIntent);
                    }
                    codes.add(String.valueOf(code));
                    scheduled++;
                } catch (SecurityException exactAlarmDenied) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pendingIntent);
                    codes.add(String.valueOf(code));
                    scheduled++;
                }
            }
        } catch (Exception ignored) {
            return 0;
        }

        prefs(context).edit().putStringSet(KEY_CODES, codes).apply();
        return scheduled;
    }

    public static void restore(Context context) {
        if (!isEnabled(context)) return;
        String json = prefs(context).getString(KEY_JSON, null);
        if (json != null) scheduleFromJson(context, json);
    }

    public static void cancelAll(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Set<String> codes = new HashSet<>(prefs(context).getStringSet(KEY_CODES, new HashSet<>()));
        if (alarmManager != null) {
            for (String raw : codes) {
                try {
                    int code = Integer.parseInt(raw);
                    Intent intent = new Intent(context, PrayerAlarmReceiver.class);
                    PendingIntent pi = PendingIntent.getBroadcast(
                            context, code, intent,
                            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
                    );
                    if (pi != null) {
                        alarmManager.cancel(pi);
                        pi.cancel();
                    }
                } catch (Exception ignored) {}
            }
        }
        prefs(context).edit().remove(KEY_CODES).apply();
    }

    private static PendingIntent pendingIntent(Context context, String prayer, int code) {
        Intent intent = new Intent(context, PrayerAlarmReceiver.class);
        intent.putExtra("prayer_name", prayer);
        return PendingIntent.getBroadcast(
                context, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static int requestCode(String prayer, long when) {
        long minutes = when / 60000L;
        return (int) ((minutes ^ prayer.hashCode()) & 0x7fffffff);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
