package com.mohamedmarey.quran;

import android.content.Context;
import android.content.SharedPreferences;

public final class AdhanPreferences {
    private static final String PREFS = "quran_marey_adhan_prefs";
    private static final String KEY_VOICE = "adhan_voice";
    private static final String DEFAULT_VOICE = "beautiful";

    private AdhanPreferences() {}

    public static void setVoice(Context context, String voice) {
        String safe = normalizeVoice(voice);
        prefs(context).edit().putString(KEY_VOICE, safe).apply();
    }

    public static String getVoice(Context context) {
        return normalizeVoice(prefs(context).getString(KEY_VOICE, DEFAULT_VOICE));
    }

    private static String normalizeVoice(String voice) {
        if ("classic".equals(voice) || "full".equals(voice) || "beautiful".equals(voice) || "tts".equals(voice)) {
            return voice;
        }
        return DEFAULT_VOICE;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
