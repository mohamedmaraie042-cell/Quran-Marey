package com.mohamedmarey.quran;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class AdminAnnouncementManager {
    public interface Callback { void onDone(boolean ok, String message); }

    private static final String OWNER = "mohamedmaraie042-cell";
    private static final String REPO = "Quran-Marey";
    private static final String FILE = "admin-notifications.json";
    private static final String API_URL = "https://api.github.com/repos/" + OWNER + "/" + REPO + "/contents/" + FILE;
    private static final String RAW_URL = "https://raw.githubusercontent.com/" + OWNER + "/" + REPO + "/main/" + FILE;
    private static final String PREFS = "al_muslim_admin_announcements";
    private static final String LAST_ID = "last_seen_id";
    private static final String CHANNEL = "admin_announcements";

    private AdminAnnouncementManager() {}

    public static void checkAndNotify(Context context) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(RAW_URL + "?t=" + System.currentTimeMillis());
            conn = (HttpURLConnection) u.openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", "Al-Muslim-Android/2.1.0");
            int code = conn.getResponseCode();
            if (code == 404) return;
            if (code < 200 || code >= 300) return;
            String raw = read(conn.getInputStream());
            JSONObject root = new JSONObject(raw);
            JSONArray messages = root.optJSONArray("messages");
            if (messages == null || messages.length() == 0) return;
            JSONObject latest = messages.optJSONObject(messages.length() - 1);
            if (latest == null) return;
            String id = latest.optString("id", "").trim();
            String title = latest.optString("title", "رسالة من إدارة المسلم").trim();
            String body = latest.optString("body", "").trim();
            long createdAt = latest.optLong("createdAt", 0L);
            if (id.isEmpty() || body.isEmpty()) return;
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            if (id.equals(p.getString(LAST_ID, ""))) return;
            if (createdAt > 0 && System.currentTimeMillis() - createdAt > 7L * 24L * 60L * 60L * 1000L) {
                p.edit().putString(LAST_ID, id).apply();
                return;
            }
            showNotification(context, id, title, body);
            p.edit().putString(LAST_ID, id).apply();
        } catch (Exception e) {
            CrashLogger.recordRuntime(context, "AdminAnnouncement", "تعذر فحص رسائل الإدارة", e.toString());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    public static void send(Context context, String token, String title, String body, Callback callback) {
        final String safeToken = token == null ? "" : token.trim();
        final String safeTitle = title == null ? "" : title.trim();
        final String safeBody = body == null ? "" : body.trim();
        if (safeToken.length() < 20) { callback.onDone(false, "أدخل GitHub token صالحًا بصلاحية Contents: Read and write."); return; }
        if (safeTitle.isEmpty() || safeBody.isEmpty()) { callback.onDone(false, "اكتب عنوان الرسالة ونصها."); return; }
        new Thread(() -> sendInternal(context, safeToken, safeTitle, safeBody, callback), "AdminAnnouncementSend").start();
    }

    private static void sendInternal(Context context, String token, String title, String body, Callback callback) {
        HttpURLConnection get = null;
        try {
            String sha = null;
            JSONArray messages = new JSONArray();
            get = openApi("GET", token);
            int getCode = get.getResponseCode();
            if (getCode >= 200 && getCode < 300) {
                JSONObject meta = new JSONObject(read(get.getInputStream()));
                sha = meta.optString("sha", null);
                String content = meta.optString("content", "").replace("\n", "");
                if (!content.isEmpty()) {
                    String decoded = new String(Base64.decode(content, Base64.DEFAULT), StandardCharsets.UTF_8);
                    try {
                        JSONObject old = new JSONObject(decoded);
                        JSONArray oldMessages = old.optJSONArray("messages");
                        if (oldMessages != null) {
                            int start = Math.max(0, oldMessages.length() - 49);
                            for (int i = start; i < oldMessages.length(); i++) messages.put(oldMessages.get(i));
                        }
                    } catch (Exception ignored) {}
                }
            } else if (getCode != 404) {
                callback.onDone(false, "GitHub رفض قراءة ملف الإشعارات (" + getCode + ").");
                return;
            }
            if (get != null) { get.disconnect(); get = null; }

            long now = System.currentTimeMillis();
            JSONObject msg = new JSONObject();
            msg.put("id", String.valueOf(now));
            msg.put("title", title);
            msg.put("body", body);
            msg.put("createdAt", now);
            messages.put(msg);
            JSONObject feed = new JSONObject();
            feed.put("updatedAt", now);
            feed.put("messages", messages);
            String encoded = Base64.encodeToString(feed.toString(2).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);

            JSONObject payload = new JSONObject();
            payload.put("message", "Admin notification from Al-Muslim app");
            payload.put("content", encoded);
            payload.put("branch", "main");
            if (sha != null && !sha.isEmpty()) payload.put("sha", sha);

            HttpURLConnection put = openApi("PUT", token);
            put.setDoOutput(true);
            byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
            put.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = put.getOutputStream()) { os.write(bytes); }
            int code = put.getResponseCode();
            if (code >= 200 && code < 300) {
                callback.onDone(true, "تم إرسال الإشعار. سيصل للأجهزة عادة خلال دقائق حسب قيود البطارية والإنترنت.");
                new Thread(() -> checkAndNotify(context), "AdminAnnouncementSelfCheck").start();
            } else {
                String err = "";
                try { err = read(put.getErrorStream()); } catch (Exception ignored) {}
                callback.onDone(false, "تعذر الإرسال عبر GitHub (" + code + "). " + shorten(err, 180));
            }
            put.disconnect();
        } catch (Exception e) {
            CrashLogger.recordRuntime(context, "AdminAnnouncement", "تعذر إرسال رسالة الإدارة", e.toString());
            callback.onDone(false, "حدث خطأ أثناء الإرسال: " + e.getClass().getSimpleName());
        } finally {
            if (get != null) get.disconnect();
        }
    }

    private static HttpURLConnection openApi(String method, String token) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API_URL).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        c.setRequestMethod(method);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("Authorization", "Bearer " + token);
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        c.setRequestProperty("User-Agent", "Al-Muslim-Admin/2.1.0");
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        return c;
    }

    private static void showNotification(Context context, String id, String title, String body) {
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "رسائل إدارة التطبيق", NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("تنبيهات يرسلها مدير تطبيق المسلم للمستخدمين");
            nm.createNotificationChannel(c);
        }
        Intent open = new Intent(context, MainActivity.class);
        open.putExtra("open_tab", "home");
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 8801, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(context, CHANNEL) : new Notification.Builder(context);
        b.setSmallIcon(R.drawable.app_icon)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_DEFAULT);
        nm.notify(8800 + Math.abs(id.hashCode() % 700), b.build());
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder s = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) s.append(line);
        r.close();
        return s.toString();
    }

    private static String shorten(String s, int max) {
        if (s == null) return "";
        String t = s.replace('\n',' ').replace('\r',' ').trim();
        return t.length() <= max ? t : t.substring(0, max);
    }
}
