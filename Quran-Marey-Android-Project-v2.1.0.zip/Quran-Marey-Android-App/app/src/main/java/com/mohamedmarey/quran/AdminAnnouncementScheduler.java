package com.mohamedmarey.quran;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

public final class AdminAnnouncementScheduler {
    private static final int JOB_ID = 8810;
    private AdminAnnouncementScheduler() {}

    public static void schedule(Context context) {
        try {
            JobScheduler js = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            JobInfo info = new JobInfo.Builder(JOB_ID, new ComponentName(context, AdminAnnouncementJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .setPeriodic(15L * 60L * 1000L)
                    .build();
            js.schedule(info);
        } catch (Exception e) {
            CrashLogger.recordRuntime(context, "AdminAnnouncementScheduler", "تعذر جدولة رسائل الإدارة", e.toString());
        }
    }

    public static void checkNow(Context context) {
        new Thread(() -> AdminAnnouncementManager.checkAndNotify(context.getApplicationContext()), "AdminAnnouncementNow").start();
    }
}
