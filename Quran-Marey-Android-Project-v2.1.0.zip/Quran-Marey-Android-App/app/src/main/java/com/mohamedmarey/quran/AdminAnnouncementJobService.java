package com.mohamedmarey.quran;

import android.app.job.JobParameters;
import android.app.job.JobService;

public class AdminAnnouncementJobService extends JobService {
    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try { AdminAnnouncementManager.checkAndNotify(getApplicationContext()); }
            finally { jobFinished(params, false); }
        }, "AdminAnnouncementPoll").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) { return true; }
}
