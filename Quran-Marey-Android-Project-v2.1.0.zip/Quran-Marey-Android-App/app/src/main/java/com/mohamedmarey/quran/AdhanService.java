package com.mohamedmarey.quran;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

public class AdhanService extends Service {
    public static final String ACTION_PLAY = "com.mohamedmarey.quran.PLAY_ADHAN";
    public static final String ACTION_STOP = "com.mohamedmarey.quran.STOP_ADHAN";
    private static final String CHANNEL_ID = "muslim_adhan_v3";
    private static final int NOTIFICATION_ID = 7411;

    // Recorded sources only. No TTS/AI generation is used for adhan.
    private static final String URL_AFASY_1 = "https://cdn.aladhan.com/audio/adhans/a9.mp3";
    private static final String URL_AFASY_2 = "https://cdn.aladhan.com/audio/adhans/a4.mp3";
    private static final String URL_AFASY_3 = "https://cdn.aladhan.com/audio/adhans/a7.mp3";
    private static final String URL_QATAMI_1 = "https://download.tvquran.com/download/TvQuran.com__Athan/TvQuran.com__08.athan.mp3";

    private MediaPlayer player;
    private PowerManager.WakeLock wakeLock;
    private String prayerName = "الصلاة";
    private String[] activeUrls = new String[0];
    private int activeUrlIndex = 0;
    private String activeMode = "full";
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAdhan();
            return START_NOT_STICKY;
        }

        prayerName = intent != null ? intent.getStringExtra("prayer_name") : "الصلاة";
        if (prayerName == null || prayerName.trim().isEmpty()) prayerName = "الصلاة";
        startForeground(NOTIFICATION_ID, buildNotification(prayerName));
        acquireWakeLock();
        activeMode = AdhanPreferences.getPrayerMode(this, prayerName);
        if ("silent".equals(activeMode)) {
            handler.postDelayed(this::stopAdhan, 30000L);
        } else {
            playRecordedAdhan();
        }
        return START_NOT_STICKY;
    }

    private void playRecordedAdhan() {
        releasePlayer();
        String voice = AdhanPreferences.getPrayerVoice(this, prayerName);
        activeUrls = "qatami".equals(voice)
                ? new String[]{URL_QATAMI_1}
                : new String[]{URL_AFASY_1, URL_AFASY_2, URL_AFASY_3};
        activeUrlIndex = 0;
        playNextRemoteSource();
    }

    private void playNextRemoteSource() {
        if (activeUrls == null || activeUrlIndex >= activeUrls.length) {
            showAdhanLoadError();
            stopAdhan();
            return;
        }
        String url = activeUrls[activeUrlIndex++];
        playSource(Uri.parse(url));
    }

    private void playSource(Uri source) {
        releasePlayer();
        try {
            player = new MediaPlayer();
            player.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(this, source);
            player.setOnPreparedListener(mp -> {
                try { mp.start(); } catch (Exception ignored) {}
                if ("short".equals(activeMode)) handler.postDelayed(this::stopAdhan, 20000L);
            });
            player.setOnCompletionListener(mp -> stopAdhan());
            player.setOnErrorListener((mp, what, extra) -> {
                CrashLogger.recordRuntime(this, "AdhanService", "تعذر تشغيل تسجيل الأذان", "what=" + what + ", extra=" + extra + ", source=" + source);
                releasePlayer();
                playNextRemoteSource();
                return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            CrashLogger.recordRuntime(this, "AdhanService", "تعذر تحميل تسجيل الأذان", e.toString());
            playNextRemoteSource();
        }
    }

    private Notification buildNotification(String prayer) {
        Intent fullScreen = new Intent(this, AdhanAlarmActivity.class);
        fullScreen.putExtra("prayer_name", prayer);
        fullScreen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fullScreenPi = PendingIntent.getActivity(this, 100, fullScreen,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent open = new Intent(this, MainActivity.class);
        open.putExtra("open_tab", "prayer");
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 102, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, AdhanService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 101, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent adhkar = new Intent(this, MainActivity.class);
        adhkar.putExtra("open_tab", "adhkar_afterPrayer");
        adhkar.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent adhkarPi = PendingIntent.getActivity(this, 103, adhkar,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setSmallIcon(R.drawable.app_icon)
                .setContentTitle("حان الآن موعد " + prayer)
                .setContentText("المسلم · أذان مسجل")
                .setContentIntent(openPi)
                .setFullScreenIntent(fullScreenPi, true)
                .setOngoing(true)
                .setAutoCancel(false)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_MAX)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "إيقاف الأذان", stopPi).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_view, "فتح المسلم", openPi).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_agenda, "أذكار بعد الصلاة", adhkarPi).build());
        return builder.build();
    }

    private void showAdhanLoadError() {
        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm == null) return;
            Intent open = new Intent(this, MainActivity.class); open.putExtra("open_tab", "prayer");
            PendingIntent pi = PendingIntent.getActivity(this, 7489, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
            b.setSmallIcon(R.drawable.app_icon)
                    .setContentTitle("تعذر تحميل تسجيل الأذان")
                    .setContentText("تحقق من الإنترنت. لن يتم استخدام أي صوت آلي بديل.")
                    .setContentIntent(pi).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH);
            nm.notify(7489, b.build());
        } catch (Exception ignored) {}
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "الأذان ومواقيت الصلاة", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("تنبيه كامل وقت الصلاة وتشغيل تسجيل الأذان المختار");
            channel.setSound(null, null);
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlMuslim:Adhan");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(10 * 60 * 1000L);
            }
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
        wakeLock = null;
    }

    private void stopAdhan() {
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        releaseWakeLock();
        stopForeground(true);
        stopSelf();
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        releaseWakeLock();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
