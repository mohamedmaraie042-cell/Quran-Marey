package com.mohamedmarey.quran;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.widget.Toast;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech textToSpeech;
    private volatile boolean ttsReady = false;
    private static final int REQ_LOCATION = 1201;
    private static final int REQ_NOTIFICATIONS = 1202;
    private LocationManager locationManager;

    @SuppressLint({"SetJavaScriptEnabled", "ObsoleteSdkInt"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(11, 59, 46));
        getWindow().setNavigationBarColor(Color.rgb(11, 59, 46));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 240, 230));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setGeolocationEnabled(true);

        initTextToSpeech();
        webView.addJavascriptInterface(new AndroidBridge(), "QuranAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternalIfNeeded(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalIfNeeded(Uri.parse(url));
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                return super.onConsoleMessage(cm);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean openExternalIfNeeded(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme();
        if (scheme == null || "file".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme)) {
            return false;
        }

        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
            }
            return true;
        }
        return false;
    }

    private void initTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                ttsReady = false;
                notifyTtsState("error", "تعذر تشغيل محرك النطق في الهاتف.");
                return;
            }

            int result = textToSpeech.setLanguage(new Locale("ar", "SA"));
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
            textToSpeech.setSpeechRate(0.88f);

            if (ttsReady) {
                notifyTtsState("ready", "محرك النطق العربي جاهز.");
            } else {
                notifyTtsState("error", "اللغة العربية غير متاحة في محرك النطق على الهاتف.");
            }
        });

        textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                notifyTtsState("start", "جاري قراءة التفسير صوتيًا...");
            }

            @Override
            public void onDone(String utteranceId) {
                notifyTtsState("done", "انتهت قراءة التفسير.");
            }

            @Override
            public void onError(String utteranceId) {
                notifyTtsState("error", "تعذر تشغيل قراءة التفسير صوتيًا.");
            }
        });
    }

    private void notifyTtsState(String state, String message) {
        if (webView == null) return;
        final String js = "window.onNativeTtsState && window.onNativeTtsState("
                + jsQuote(state) + "," + jsQuote(message) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private static String jsQuote(String value) {
        if (value == null) return "null";
        return "\"" + value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r") + "\"";
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void copyToClipboard(String text) {
            if (text == null) return;
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    clipboard.setPrimaryClip(ClipData.newPlainText("Quran Marey", text));
                }
            });
        }

        @JavascriptInterface
        public boolean isTtsReady() {
            return ttsReady;
        }

        @JavascriptInterface
        public void speakArabic(String text) {
            if (text == null || text.trim().isEmpty()) return;
            runOnUiThread(() -> {
                if (!ttsReady || textToSpeech == null) {
                    notifyTtsState("error", "محرك النطق العربي غير جاهز على الهاتف.");
                    return;
                }
                String utteranceId = "tafsir-" + System.currentTimeMillis();
                int result = textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
                if (result == TextToSpeech.ERROR) {
                    notifyTtsState("error", "تعذر بدء قراءة التفسير صوتيًا.");
                }
            });
        }

        @JavascriptInterface
        public void stopTts() {
            runOnUiThread(() -> {
                if (textToSpeech != null) textToSpeech.stop();
                notifyTtsState("stopped", "تم إيقاف صوت التفسير.");
            });
        }

        @JavascriptInterface
        public void setAdhanEnabled(boolean enabled) {
            runOnUiThread(() -> {
                PrayerAlarmScheduler.setEnabled(MainActivity.this, enabled);
                if (enabled && Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                }
                notifyAdhanState(enabled ? "enabled" : "disabled",
                        enabled ? "تم تفعيل الأذان. سيتم تشغيله في المواقيت المجدولة." : "تم إيقاف الأذان وإلغاء التنبيهات المجدولة.");
            });
        }

        @JavascriptInterface
        public boolean isAdhanEnabled() {
            return PrayerAlarmScheduler.isEnabled(MainActivity.this);
        }

        @JavascriptInterface
        public void schedulePrayerAlarms(String json) {
            runOnUiThread(() -> {
                int count = PrayerAlarmScheduler.scheduleFromJson(MainActivity.this, json);
                notifyAdhanState("scheduled", "تمت جدولة " + count + " صلاة قادمة على الهاتف.");
            });
        }

        @JavascriptInterface
        public void previewAdhan() {
            runOnUiThread(() -> {
                Intent service = new Intent(MainActivity.this, AdhanService.class);
                service.setAction(AdhanService.ACTION_PLAY);
                service.putExtra("prayer_name", "الصلاة");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
                else startService(service);
            });
        }

        @JavascriptInterface
        public void stopAdhan() {
            runOnUiThread(() -> {
                Intent service = new Intent(MainActivity.this, AdhanService.class);
                service.setAction(AdhanService.ACTION_STOP);
                startService(service);
            });
        }

        @JavascriptInterface
        public void setAdhanVoice(String voice) {
            AdhanPreferences.setVoice(MainActivity.this, voice);
            notifyAdhanState("voice", "تم اختيار صوت الأذان.");
        }

        @JavascriptInterface
        public String getAdhanVoice() {
            return AdhanPreferences.getVoice(MainActivity.this);
        }

        @JavascriptInterface
        public boolean canScheduleExactAlarms() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
            android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        }

        @JavascriptInterface
        public boolean canUseFullScreenAdhan() {
            if (Build.VERSION.SDK_INT < 34) return true;
            android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
            return nm != null && nm.canUseFullScreenIntent();
        }

        @JavascriptInterface
        public void openAdhanPermissions() {
            runOnUiThread(MainActivity.this::openAdhanPermissionSettings);
        }

        @JavascriptInterface
        public void requestLocation() {
            runOnUiThread(MainActivity.this::requestPrayerLocation);
        }

        @JavascriptInterface
        public void requestPrayerTimes(String url, String requestId) {
            final String safeUrl = url == null ? "" : url.trim();
            final String safeId = requestId == null ? "" : requestId.trim();
            new Thread(() -> {
                HttpURLConnection conn = null;
                try {
                    Uri uri = Uri.parse(safeUrl);
                    String host = uri.getHost();
                    if (!"https".equalsIgnoreCase(uri.getScheme()) || host == null || !host.equalsIgnoreCase("api.aladhan.com")) {
                        notifyPrayerResponse(safeId, false, "رابط خدمة المواقيت غير مسموح.");
                        return;
                    }
                    conn = (HttpURLConnection) new URL(safeUrl).openConnection();
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(12000);
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setRequestProperty("User-Agent", "Al-Muslim-Android/1.4.2");
                    int code = conn.getResponseCode();
                    if (code < 200 || code >= 300) {
                        notifyPrayerResponse(safeId, false, "تعذر تحميل المواقيت من الخادم (" + code + ").");
                        return;
                    }
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder out = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) out.append(line);
                    reader.close();
                    notifyPrayerResponse(safeId, true, out.toString());
                } catch (Exception e) {
                    notifyPrayerResponse(safeId, false, "تعذر الاتصال بخدمة مواقيت الصلاة.");
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }, "PrayerTimesFetch").start();
        }

        @JavascriptInterface
        public void downloadAudio(String url, String fileName) {
            runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(url == null ? "" : url.trim());
                    if (!"https".equalsIgnoreCase(uri.getScheme())) {
                        notifyDownloadState("error", "رابط التنزيل غير آمن أو غير صالح.", "");
                        return;
                    }

                    String safeName = sanitizeFileName(fileName);
                    if (safeName.isEmpty()) safeName = "quran-audio.mp3";
                    if (!safeName.toLowerCase(Locale.US).endsWith(".mp3")) safeName += ".mp3";

                    DownloadManager.Request request = new DownloadManager.Request(uri);
                    request.setTitle(safeName.replace(".mp3", ""));
                    request.setDescription("Quran Marey - تلاوة القرآن الكريم");
                    request.setMimeType("audio/mpeg");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setAllowedOverMetered(true);
                    request.setAllowedOverRoaming(false);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "QuranMarey/" + safeName);
                    } else {
                        request.setDestinationInExternalFilesDir(MainActivity.this, Environment.DIRECTORY_MUSIC, "QuranMarey/" + safeName);
                    }

                    DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (manager == null) {
                        notifyDownloadState("error", "خدمة التنزيل غير متاحة على الهاتف.", safeName);
                        return;
                    }

                    long id = manager.enqueue(request);
                    Toast.makeText(MainActivity.this, "بدأ تنزيل التلاوة", Toast.LENGTH_SHORT).show();
                    notifyDownloadState("started", "بدأ تنزيل التلاوة. سيظهر إشعار عند اكتمالها ويمكن العثور عليها داخل مجلد QuranMarey.", safeName + "#" + id);
                } catch (Exception e) {
                    notifyDownloadState("error", "تعذر بدء تنزيل التلاوة.", "");
                }
            });
        }
    }

    private void openAdhanPermissionSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (am != null && !am.canScheduleExactAlarms()) {
                    Intent exact = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(exact);
                    notifyAdhanState("permission", "فعّل السماح بالتنبيهات الدقيقة، ثم ارجع للتطبيق واضغط الزر مرة أخرى.");
                    return;
                }
            }
            if (Build.VERSION.SDK_INT >= 34) {
                android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
                if (nm != null && !nm.canUseFullScreenIntent()) {
                    Intent full = new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT",
                            Uri.parse("package:" + getPackageName()));
                    startActivity(full);
                    notifyAdhanState("permission", "اسمح للتطبيق بعرض تنبيه ملء الشاشة وقت الأذان.");
                    return;
                }
            }
            notifyAdhanState("permission_ready", "✅ إعدادات الأذان المهمة مفعّلة على الهاتف.");
        } catch (Exception e) {
            try {
                Intent details = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(details);
            } catch (Exception ignored) {}
        }
    }

    private void notifyAdhanState(String state, String message) {
        if (webView == null) return;
        final String js = "window.onNativeAdhanState && window.onNativeAdhanState("
                + jsQuote(state) + "," + jsQuote(message) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void notifyPrayerResponse(String requestId, boolean ok, String payload) {
        if (webView == null) return;
        final String js = "window.onNativePrayerTimes && window.onNativePrayerTimes("
                + jsQuote(requestId) + "," + (ok ? "true" : "false") + "," + jsQuote(payload) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void notifyLocation(Location location) {
        if (webView == null || location == null) return;
        final String js = "window.onNativeLocation && window.onNativeLocation("
                + location.getLatitude() + "," + location.getLongitude() + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void notifyLocationError(String message) {
        if (webView == null) return;
        final String js = "window.onNativeLocationError && window.onNativeLocationError(" + jsQuote(message) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private void requestPrayerLocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        fetchPrayerLocation();
    }

    @SuppressLint("MissingPermission")
    private void fetchPrayerLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (locationManager == null) {
                notifyLocationError("خدمة الموقع غير متاحة على الهاتف.");
                return;
            }

            Location best = null;
            String[] providers = new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER};
            for (String provider : providers) {
                try {
                    Location loc = locationManager.getLastKnownLocation(provider);
                    if (loc != null && (best == null || loc.getTime() > best.getTime())) best = loc;
                } catch (Exception ignored) {}
            }
            if (best != null && System.currentTimeMillis() - best.getTime() < 6L * 60L * 60L * 1000L) {
                notifyLocation(best);
                return;
            }

            String provider = null;
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) provider = LocationManager.NETWORK_PROVIDER;
            else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) provider = LocationManager.GPS_PROVIDER;

            if (provider == null) {
                if (best != null) notifyLocation(best);
                else notifyLocationError("فعّل خدمة الموقع GPS ثم حاول مرة أخرى.");
                return;
            }

            final Location fallback = best;
            LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    notifyLocation(location);
                    try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
                }
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            };
            locationManager.requestSingleUpdate(provider, listener, Looper.getMainLooper());
            webView.postDelayed(() -> {
                if (fallback != null) notifyLocation(fallback);
                else notifyLocationError("تعذر تحديد الموقع بسرعة. يمكنك كتابة المدينة يدويًا.");
                try { locationManager.removeUpdates(listener); } catch (Exception ignored) {}
            }, 9000L);
        } catch (Exception e) {
            notifyLocationError("تعذر الوصول إلى الموقع. يمكنك كتابة المدينة يدويًا.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) fetchPrayerLocation();
            else notifyLocationError("تم رفض إذن الموقع. اكتب المدينة يدويًا أو اسمح بالموقع من إعدادات التطبيق.");
        } else if (requestCode == REQ_NOTIFICATIONS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            notifyAdhanState(granted ? "notification_ready" : "notification_denied",
                    granted ? "تم السماح بإشعارات الصلاة." : "الأذان مفعّل، لكن إشعار الصلاة قد لا يظهر لأن إذن الإشعارات مرفوض.");
        }
    }

    private static String sanitizeFileName(String value) {
        if (value == null) return "";
        return value.replaceAll("[\\/:*?\"<>|\n\r\t]", "-").trim();
    }

    private void notifyDownloadState(String state, String message, String data) {
        if (webView == null) return;
        final String js = "window.onNativeDownloadState && window.onNativeDownloadState("
                + jsQuote(state) + "," + jsQuote(message) + "," + jsQuote(data) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }

        webView.evaluateJavascript(
                "window.handleAndroidBack ? window.handleAndroidBack() : false",
                value -> {
                    if (!"true".equalsIgnoreCase(String.valueOf(value))) {
                        if (webView != null && webView.canGoBack()) {
                            webView.goBack();
                        } else {
                            MainActivity.super.onBackPressed();
                        }
                    }
                }
        );
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
            textToSpeech = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("QuranAndroid");
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
